<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Stripe, Mailgun, Mandrill, and others. This file provides a sane
    | default location for this type of information, allowing packages
    | to have a conventional place to find your various credentials.
    |
    */

    'mailgun' => [
        'domain' => env('sandboxa6db6558a6b34e32bdb5fac3f849a24d.mailgun.org'),
        'secret' => env('key-f56bb08cf97ddccce212f7d0c147f246'),
    ],

    'mandrill' => [
        'secret' => env('MANDRILL_SECRET'),
    ],

    'ses' => [
        'key'    => env('SES_KEY'),
        'secret' => env('SES_SECRET'),
        'region' => 'us-east-1',
    ],

    'stripe' => [
        'model'  => App\User::class,
        'key'    => env('STRIPE_KEY'),
        'secret' => env('STRIPE_SECRET'),
    ],
    'facebook' => [
        'client_id' => '887918251324124',
        'client_secret' => '47a1d516950c3f18bfb60febb3fe75f1',
        'redirect' => 'http://facilitz.com/account/facebook',
    ],
    'linkedin' => [
        'client_id' => '75aq2a8aw6lado',
        'client_secret' => 'ad8WZxkRhR8aWNJP',
        'redirect' => 'http://facilitz.com/account/linkedin',
    ],
    'google' => [
        'client_id' => '38518982245-hga9jq9rqbpidld723vkihe7ngciet6j.apps.googleusercontent.com',
        'client_secret' => 'y4U28nVMbPiO0pVp3VzCyvsx',
        'redirect' => 'http://facilitz.com/account/google',
    ],
    'twitter' => [
        'client_id' => 'tEqbs2KD1nJita15HKkMt6SJt',
        'client_secret' => 'uSHAeMprK9VB1rXCXheICHdYOg0ez7iACDk4nzM3RknDKilfk0',
        'redirect' => 'http://facilitz.com/account/twitter',
    ],

];












