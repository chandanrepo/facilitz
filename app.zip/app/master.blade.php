<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Facilitz</title>

    <!-- Bootstrap Core CSS -->
    <link href="facilitiz/css/bootstrap.css" rel="stylesheet">
    <link href="facilitiz/css/bootstrap.social.css" rel="stylesheet">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <!-- Custom CSS -->
    <link href="facilitiz/css/scrolling-nav.css" rel="stylesheet">


</head>


<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">

    <!-- Navigation -->

<nav class="[ navbar navbar-fixed-top ][ navbar-bootsnipp animate ]" role="navigation">
  <div class="col-lg-6">
     <!-- Brand and toggle get grouped for better mobile display -->
            <div class="[ navbar-header ]">
                <button type="button" id="responsive-menu" class="[ navbar-toggle ]" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="[ sr-only ]">Toggle navigation</span>
                    <span class="[ icon-bar ]"></span>
                    <span class="[ icon-bar ]"></span>
                    <span class="[ icon-bar ]"></span>
                </button>
                <div class="[ animbrand ]">
                    <a class="[ navbar-brand ][ animate ]" href="#">
                        <img src="facilitiz/img/facilitiz_logo.png" id="responsive-logo" alt="logo" /> 
                        </a>
                </div>
            </div>
            <div class="input-group-btn search-panel" id="topsearch">
                <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                <span class="glyphicon glyphicon-map-marker marker_icon"></span>
                    <span id="search_concept">Bangalore</span> 
                </button>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="#contains">New delhi</a></li>
                  <li><a href="#its_equal">Mumbai</a></li>
                  <li><a href="#greather_than">Kolkata</a></li>
                  <li><a href="#less_than">Ahmedabad</a></li>
                  <li class="divider"></li>
                  <li><a href="#all">Anything</a></li>
                </ul>
            </div>
  </div>
  <div class="col-lg-6">
    <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="[ collapse navbar-collapse ]" id="bs-example-navbar-collapse-1">
                <ul class="[ nav navbar-nav navbar-right ]" style="background:#fff;">
                    <li class="[ visible-xs ]">
                    </li>
                    <li><a href="/dashboard" class="[ animate ]">Track My Quote</a></li>
                    <li><a href="/dashboard" class="[ animate ]">AMC</a></li>
                    <li><a href="#" class="[ animate ]">Afliate Business</a></li>
                    <li><a href="#" class="[ animate ]">Blog</a></li>
                    <!-- <li>
                        <a href="#" class="[ dropdown-toggle ][ animate ]" data-toggle="dropdown">Resources <span class="[ caret ]"></span></a>
                        <ul class="[ dropdown-menu ]" role="menu">
                            <li><a href="#" class="[ animate ]">Blog <span class="[ pull-right glyphicon glyphicon-pencil ]"></span></a></li>
                            <li><a href="#" class="[ animate ]">List of resources <span class="[ pull-right glyphicon glyphicon-align-justify ]"></span></a></li>
                            <li><a href="#" class="[ animate ]">Download Bootstrap <span class="[ pull-right glyphicon glyphicon-cloud-download ]"></span></a></li>
                            <li class="[ dropdown-header ]">Bootstrap Templates</li>
                            <li><a href="#" class="[ animate ]">Browse Templates <span class="[ pull-right glyphicon glyphicon-shopping-cart ]"></span></a></li>
                            <li class="[ dropdown-header ]">Builders</li>
                            <li><a href="#" class="[ animate ]">Form Builder <span class="[ pull-right glyphicon glyphicon-tasks ]"></span></a></li>
                            <li><a href="#" class="[ animate ]">Button Builder <span class="[ pull-right glyphicon glyphicon-edit ]"></span></a></li>
                        </ul>
                    </li>
                    <li class="[ dropdown ]">
                        <a href="#" class="[ dropdown-toggle ][ animate ]" data-toggle="dropdown">Snippets <span class="[ caret ]"></span></a>
                        <ul class="[ dropdown-menu ]" role="menu">
                            <li><a href="#" class="[ animate ]">Featured <span class="[ pull-right glyphicon glyphicon-star ]"></span></a></li>
                            <li><a href="#" class="[ animate ]">Tags  <span class="[ pull-right glyphicon glyphicon-tags ]"></span></a></li>
                            <li class="[ dropdown-header ]">By Bootstrap Version</li>
                            <li><a href="#" class="[ animate ]">3.2.0</a></li>
                            <li><a href="#" class="[ animate ]">3.1.0</a></li>
                            <li><a href="#" class="[ animate ]">3.0.3</a></li>
                            <li><a href="#" class="[ animate ]">3.0.1</a></li>
                            <li><a href="#" class="[ animate ]">3.0.0</a></li>
                            <li><a href="#" class="[ animate ]">2.3.2</a></li>
                        </ul>
                    </li> -->
                    @if($id==0)
                    <li><a class="animate" data-toggle="modal" href="#login_register_model">Login</a></li>
                    @else
                    <li class="[ dropdown ]">
                        <a href="#" class="[ dropdown-toggle ][ animate ]" data-toggle="dropdown">{{$name}}</a>
                        <ul class="[ dropdown-menu ]" role="menu">
                            <li><a href="/auth/logout" class="[ animate ]">Logout</a></li>
                        </ul>
                    </li>
                    @endif
                </ul>
            </div>
        
  </div>
        
                       
            
            
        <div class="[ bootsnipp-search animate ]">
            <div class="[ container ]">
                <form action="http://bootsnipp.com/search" method="GET" role="search">
                    <div class="[ input-group ]">
                        <input type="text" class="[ form-control ]" name="q" placeholder="Search for snippets and hit enter">
                        <span class="[ input-group-btn ]">
                            <button class="[ btn btn-danger ]" type="reset"><span class="[ glyphicon glyphicon-remove ]"></span></button>
                        </span>
                    </div>
                </form>
            </div>
        </div>
    </nav>
    <!-- Intro Section -->

 <div class="container">
    <div class="row">
        <!-- Carousel -->
        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                <li data-target="#carousel-example-generic" data-slide-to="2"></li>
            </ol>
            <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox">
                <div class="item active">
                    <img class="img-responsive img-height" src="http://unsplash.s3.amazonaws.com/batch%209/barcelona-boardwalk.jpg" alt="First slide">
                    
                </div>
                <div class="item">
                    <img class="img-responsive img-height" src="http://unsplash.s3.amazonaws.com/batch%209/barcelona-boardwalk.jpg" alt="Second slide">
                    <!-- Static Header -->
                     
                </div>
                <div class="item">
                    <img class="img-responsive img-height" src="http://unsplash.s3.amazonaws.com/batch%209/barcelona-boardwalk.jpg" alt="Third slide">
                    <!-- Static Header -->
                  
                </div>
            </div>
            <!-- Controls -->
            <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                <span class="glyphicon glyphicon-chevron-left"></span>
            </a>
            <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                <span class="glyphicon glyphicon-chevron-right" ></span>
            </a>
        </div><!-- /carousel -->
        <!-- Static Header -->
        <div class="header-text row row-centered">
        <div class="col-lg-6 col-sm-12 col-xs-12 col-centered text-center ">
        
          
            <form class="section3_form" method="post" action="">
              <h3 class="form_header"> What service you want? </h3>
              <div class="col-lg-12 ">
                <span class="input-group-btn" style="float:right;width:12%">
                <button class="btn btn-default" data-toggle="modal" data-target="#myModal" style="height: 50px;border:none;"  id="submit_btn" type="button">Next</button>
                </span>
                <div class="input-group" style="width:88%">
                  <input type="hidden" name="search_param" value="all" id="search_param">
                  <input type="text" class="form-control location" id="location1" name="y" placeholder="Location" style="width:35%">
                  <input type="text" class="form-control" id="searchkey1" name="x" placeholder="Search for plumber, painting etc." style="width:65%">
                </div>
              </div>
            </form>
          </div>
        </div><!-- /header-text -->
    </div>
</div>




    <!-- About Section -->



 @yield('content')




 <section class="section_footer">
     <div class="container">
         <div class="row section5-col">
                    
                    <div class="col-lg-4 left-col">
                       <ul class="ul_lists left_list">
                         <li><img src="facilitiz/img/facilitiz_logo.png" alt=""/></li>
                         <li><p>Facilitz is a group of enthusiastic IT engineers and IIM skilled Management professionals having a dream to change the world with their creative thoughts and ideas. Facilitz brings to you the latest in architecture, art, furnishings, technology, 
and interior décor. Fresh and never sour, the trends we bring satiate the thirst and spruce the ambience with a touch of all things luxe at affordable price points.</p></li>
                         <li style="text-align:center;"><a href=""><i class="fa fa-facebook fa-5 icon_icon"></i></a>
                             <a href=""><i class="fa fa-twitter fa-5 icon_icon "></i></a>
                             <a href=""><i class="fa fa-linkedin fa-5 icon_icon"></i></a>
                             <a href=""><i class="fa fa-google-plus fa-5 icon_icon "></i></a>
                             <a href=""><i class="fa fa-skype fa-5 icon_icon "></i></a>
                             <a href=""><i class="fa fa-youtube fa-5 icon_icon"></i></a>
                             </li>
                        </ul>

                    </div>
                    <div class="col-lg-4">
                     <ul class="ul_lists">
                         <li><h4>Company</h4></li>
                         <li><a href="">About us</a></li>
                         <li><a href="">Blog</a></li>
                         <li><a href="">Meadia talk</a></li>
                     </ul>
                     <ul class="ul_lists">
                         <li><h4>Policy</h4></li>
                         <li><a href="">Privacy policy</a></li>
                         <li><a href="">Faqs</a></li>
                         <li><a href="">Terms & conditions</a></li>
                     </ul>

                    </div>
                    <div class="col-lg-4" style="">
                       <ul class="ul_lists">
                         <li><h4>Services</h4></li>
                         <li><a href="">Privacy policy</a></li>
                         <li><a href="">Faqs</a></li>
                         <li><a href="">Terms & conditions</a></li>
                         <li><a href="">Privacy policy</a></li>
                         <li><a href="">Faqs</a></li>
                         <li><a href="">Terms & conditions</a></li>
                     </ul>
                    </div>
                    <!-- <div class="col-lg-1">
                    </div> -->
            </div>
            <div class="row row-centered">
                <div class="col-lg-11 col-centered">
                    <hr/>
                    <div class="row row-centered">
                    <div class="col-lg-6 col-centered" style="text-align:center;">
                            Copyright © 2015-2016 Facilitz Concierge Services Pvt. Ltd. All Rights Reserved.
                        <hr/>
                    </div></div>

                </div>
            </div>
        </div>
    </section>






 <div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-sm">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Please fill this form</h4>
      </div>
      <div class="modal-body">
        <form role="form" id="quoteform1">
           <input class="form-control" id="email1" name="email" placeholder="Enter your email address." type="email" required />
           <input class="form-control" id="phone1" name="phone" placeholder="Enter valid phone number." type="number" required />
           <input type="hidden" name="_token" id="_token" value="{{{ csrf_token() }}}" />
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" id="sbt_btn1" onclick="fn_submitquote(1)" class="btn btn-default btn-success">Get a call back</button>
      </div>
    </div>

  </div>
</div>

<div id="myModal2" class="modal fade" role="dialog">
  <div class="modal-dialog modal-sm">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Please fill this form</h4>
      </div>
      <div class="modal-body">
        <form role="form" id="quoteform2">
           <input class="form-control" id="email2" name="email" placeholder="Enter your email address." type="email" required />
           <input class="form-control" id="phone2" name="phone" placeholder="Enter valid phone number." type="number" required />
           
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" id="sbt_btn2" onclick="fn_submitquote(2)" class="btn btn-default btn-success">Get a call back</button>
      </div>
    </div>

  </div>
</div>
<div id="myModal3" class="modal fade" role="dialog">
  <div class="modal-dialog modal-sm">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Please fill this form</h4>
      </div>
      <div class="modal-body">
        <form role="form" id="quoteform3">
           <input class="form-control" id="email3" name="email" placeholder="Enter your email address." type="email" required />
           <input class="form-control" id="phone3" name="phone" placeholder="Enter valid phone number." type="number" required />
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" id="sbt_btn3" onclick="fn_submitquote(3)" class="btn btn-default btn-success">Get a call back</button>
      </div>
    </div>

  </div>
</div>





  <div class="modal fade" id="login_register_model" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    ×</button>
                <h4 class="modal-title" id="myModalLabel">
                    Login/Registration form</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-8" style="border-right: 1px dotted #C2C2C2;padding-right: 30px;">
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs">
                            <li class="active"><a href="#Login" data-toggle="tab">Login</a></li>
                            <li><a href="#Registration" data-toggle="tab">Registration</a></li>
                        </ul>
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div class="tab-pane active" id="Login">
                              @if (count($errors) > 0)
                                <div class="alert alert-danger">
                                  <strong>Whoops!</strong> There were some problems with your input.<br><br>
                                  <ul>
                                    @foreach ($errors->all() as $error)
                                      <li>{{ $error }}</li>
                                    @endforeach
                                  </ul>
                                </div>
                              @endif
                                <form class="form-horizontal" role="form" method="POST" action="{{ url('/auth/login') }}" style="width:80%">
                                <div class="form-group">
                                  {!! csrf_field() !!}
                                    <label for="email" class="col-sm-2 control-label">
                                        Email</label>
                                    <div class="col-sm-10">
                                        <input type="email" class="form-control" id="email1" placeholder="Email" name="email" required />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1" class="col-sm-2 control-label">
                                        Password</label>
                                    <div class="col-sm-10">
                                        <input type="password" class="form-control" id="exampleInputPassword1" name="password" placeholder="password" required />
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-2">
                                    </div>
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            Submit</button>
                                        <a href="javascript:;">Forgot your password?</a>
                                    </div>
                                </div>
                                </form>
                            </div>
                            <div class="tab-pane" id="Registration">
          @if (count($errors) > 0)
            <div class="alert alert-danger">
              <strong>Whoops!</strong> There were some problems with your input.<br><br>
              <ul>
                @foreach ($errors->all() as $error)
                  <li>{{ $error }}</li>
                @endforeach
              </ul>
            </div>
          @endif
          <form class="form-horizontal" role="form" method="POST" action="{{ url('/auth/register') }}" style="width:80%">
            {!! csrf_field() !!}
                                <div class="form-group">
                                    <label for="email" class="col-sm-2 control-label">
                                        Name</label>
                                    <div class="col-sm-10">
                                        <div class="row">
                                            <div class="col-md-3">
                                                <select class="form-control">
                                                    <option>Mr.</option>
                                                    <option>Ms.</option>
                                                    <option>Mrs.</option>
                                                </select>
                                            </div>
                                            <div class="col-md-9">
                                               <input type="text" class="form-control" name="name" value="{{ old('name') }}" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="email" class="col-sm-2 control-label">
                                        Email</label>
                                    <div class="col-sm-10">
                                        <input type="email" class="form-control" name="email" value="{{ old('email') }}" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="mobile" class="col-sm-2 control-label">
                                        Mobile</label>
                                    <div class="col-sm-10">
                                        <input type="number" class="form-control" name="phn">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="password" class="col-sm-2 control-label">
                                        Password</label>
                                    <div class="col-sm-10">
                                       <input type="password" class="form-control" name="password" required>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-2">
                                    </div>
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            Save & Continue</button>
    
                                    </div>
                                </div>
                                </form>
                            </div>
                        </div>
                        <div id="OR" class="hidden-xs">
                            OR</div>
                    </div>
                    <div class="col-md-4">
                        <div class="row text-center sign-with">
                            <!-- <div class="col-md-12">
                                <h3>
                                    Sign in with</h3>
                            </div> -->
                            <div class="col-md-12">
                                <a class="btn btn-block btn-social btn-facebook" href="{!!URL::to('facebook')!!}">
                                <span class="fa fa-facebook"></span>
                                Sign in with Facebook
                                </a>
                                <a class="btn btn-block btn-social btn-linkedin" href="{!!URL::to('linkedin')!!}">
                                <span class="fa fa-linkedin"></span>
                                Sign in with LinkedIn
                                </a>
                                <a class="btn btn-block btn-social btn-google" href="{!!URL::to('google')!!}">
                                <span class="fa fa-google-plus"></span>
                                Sign in with Google
                                </a>
                                <a class="btn btn-block btn-social btn-twitter" href="{!!URL::to('twitter')!!}">
                                <span class="fa fa-twitter"></span>
                                Sign in with Twitter
                                </a>
                               <!--  <div class="btn-group btn-group-justified">
                                    <a href="#" class="btn btn-primary">Facebook</a> <a href="#" class="btn btn-danger">
                                        Google</a>
                                </div> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>







    <!-- Contact Section -->
    <!-- jQuery -->
    <script src="facilitiz/js/jquery.js"></script>
    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <!-- Bootstrap Core JavaScript -->
    <script src="facilitiz/js/bootstrap.min.js"></script>

    <!-- Scrolling Nav JavaScript -->
    <script src="facilitiz/js/scrolling-nav.js"></script>
    <script type="text/javascript" src="facilitiz/js/validation.js"></script>
    <script type="text/javascript">
    // $(document).ready(function () { $(function () { $('#carousel-example-generic').carousel({ interval: 3000 }); }); });
        $( "input.location" ).autocomplete({
        source: function( request, response ) {
            //alert(request);
            //console.log(request.term);
            var url = "/gapi/"+request.term;
        $.getJSON( url, function( data ) {
          response(data);
        });
            //response(data);
        },
        minLength: 3,
        open: function() {},
        close: function() {},
        focus: function(event,ui) {},
        select: function(event, ui) {}
        });
        function fn_submitquote(id) {
            var validator = $( "#quoteform"+id).validate({ errorPlacement: function(error, element) {} });
            if(validator.form()){
              $('#sbt_btn'+id).css('pointer-events','none');
                var dataparam = "services="+$('#searchkey'+id).val()+"&email="+$('#email'+id).val()+"&phone="+$('#phone'+id).val()+"&location="+$('#location'+id).val()+"&_token="+$('#_token').val();
                $.ajax({
                  method: "POST",
                  url: "/savecontact",
                  data: dataparam
                })
                  .done(function( msg ) {
                    alert("Your request submitted successfully. We will contact you soon!");
                    window.location="/";
                  });
            }
        }
    </script>
</body>

</html>
