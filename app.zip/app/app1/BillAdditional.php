<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BillAdditional extends Model
{
    protected $fillable = ['description','amount','bill_id'];
}
