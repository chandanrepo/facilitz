<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Installments extends Model
{
    protected $fillable = ['bill_id','amount'];
}
