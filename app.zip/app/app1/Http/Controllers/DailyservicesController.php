<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use Auth;
use Illuminate\Support\Facades\Input;
use App\CarTypes;
use Validator;
use Redirect;
use App\Vehiclewashes;
class DailyservicesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
            
    }
    public function savevehiclewash(Request $request){        
        $data = $request->all();
        $date = date('Y-m-d H:i:s');
        $hidcartype = explode(',',$data['hidcartype']);
        $hidnoofcars = explode(',',$data['hidnoofcars']);
        $hidrno = explode(',',$data['hidrno']);
        $total_amount = $data['total_amount'];
        $grand_total = $data['hidtotal_amount'];
        $hidprice = explode(',',$data['hidprice']);
        $userid = Auth::user()->id;
        $date = date('Y-m-d H:i:s');
        if($total_amount>0){
            // insert into vehiclewash master table
            $input = array('user_id'=>$userid,'total_amount'=>$total_amount,'grand_total'=>$grand_total,'month'=>$data['hidmonth'],'valid_till'=>date("Y-m-d",strtotime($data['hidvalidtill'])));
            $res = Vehiclewashes::create($input);
            $vid = $res->{'id'};
            $typeinsarray=array();
            $rnoinsarray=array();
            for ($i=0; $i < sizeof($hidcartype) ; $i++) { 
                $typeinsarray[]=array('vehiclewash_id'=>$vid,'car_type_id'=>$hidcartype[$i],'no_of_cars'=>$hidnoofcars[$i],'amount'=>$hidprice[$i],'created_at'=>$date,'updated_at'=>$date);
                //registration number
                $tmp = explode('~',$hidrno[$i]);
                for ($j=0; $j < sizeof($tmp) ; $j++) { 
                    $rnoinsarray[]=array('vehiclewash_id'=>$vid,'rno'=>$tmp[$i],'created_at'=>$date,'updated_at'=>$date);
                }
            }
            if(sizeof($typeinsarray)>0)
                DB::table('vehilclewash_type_mapping')->insert($typeinsarray);
            if(sizeof($rnoinsarray)>0)
                DB::table('vehilclewash_rno_mapping')->insert($rnoinsarray);
        }
        return redirect('/dashboard')->with('status', 'Your request Submitted successfully!');
    }
}