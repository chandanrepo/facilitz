<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

use DB;
use Auth;
use Illuminate\Http\Request;
use App\Messages;
use App\RequestLocations;
class IndexController extends Controller
{
    public function index(){
    	// $data = DB::select('laravel5');
    	// $result=DB::table('products')->get();
    	$id=0;
    	$name='';
    	if(Auth::check()){
    		$id = Auth::user()->id;
    		$name = Auth::user()->name;
    	}
        $services = DB::table('services')->get(array('service_name'));
        $tmp=array();
        foreach ($services as $key => $value) {
            $tmp[]=$value->service_name;
        }			
    	return view('facilitiz.index')->with('id',$id)->with('name',$name)->with('services',$tmp);
    }
    public function vehiclewash(){
        $id=0;
        $name='';
        if(Auth::check()){
            $id = Auth::user()->id;
            $name = Auth::user()->name;
        }
        $cartype = DB::table('car_types')->get();
        return view('dailyservices.vehiclewash',compact('cartype'))->with('id',$id)->with('name',$name); 
    }
    public function amcview(){
        $id=0;
        $name='';
        if(Auth::check()){
            $id = Auth::user()->id;
            $name = Auth::user()->name;
        }
        $amcdata = DB::table('amc_services')->select(DB::raw('GROUP_CONCAT(services.service_name) as service_name,GROUP_CONCAT(amc_services.price) as price,GROUP_CONCAT(amc_services.visits) as visits,amcs.no_of_services'))->leftJoin('services', 'services.id', '=', 'amc_services.service_id')->leftJoin('amcs', 'amcs.id', '=', 'amc_services.amc_id')->groupBy('amc_services.amc_id')->orderBy('amc_services.amc_id', 'ASC')->get();
        $servicedata = DB::table('amc_services')->leftJoin('services', 'amc_services.service_id', '=', 'services.id')->where('amc_services.amc_id','=',1)->get(array('amc_services.*','services.service_name'));
        $locationdata = DB::table('locations')->get();
        return view('amc.index',compact('servicedata','amcdata','locationdata'))->with('id',$id)->with('name',$name); 
    }
    public function diamond(){
        $id=0;
        $name='';
        if(Auth::check()){
            $id = Auth::user()->id;
            $name = Auth::user()->name;
        }
        $amcdata = DB::table('amc_services')->select(DB::raw('GROUP_CONCAT(services.service_name) as service_name,GROUP_CONCAT(amc_services.price) as price,GROUP_CONCAT(amc_services.visits) as visits,amcs.no_of_services'))->leftJoin('services', 'services.id', '=', 'amc_services.service_id')->leftJoin('amcs', 'amcs.id', '=', 'amc_services.amc_id')->where('amc_services.amc_id','=',2)->groupBy('amc_services.amc_id')->orderBy('amc_services.amc_id', 'ASC')->first();
        $locationdata = DB::table('locations')->get();
        return view('amc.diamond',compact('amcdata','locationdata'))->with('id',$id)->with('name',$name);
    }
    public function silver(){
        $id=0;
        $name='';
        if(Auth::check()){
            $id = Auth::user()->id;
            $name = Auth::user()->name;
        }
        $amcdata = DB::table('amc_services')->select(DB::raw('GROUP_CONCAT(services.service_name) as service_name,GROUP_CONCAT(amc_services.price) as price,GROUP_CONCAT(amc_services.visits) as visits,amcs.no_of_services'))->leftJoin('services', 'services.id', '=', 'amc_services.service_id')->leftJoin('amcs', 'amcs.id', '=', 'amc_services.amc_id')->where('amc_services.amc_id','=',3)->groupBy('amc_services.amc_id')->orderBy('amc_services.amc_id', 'ASC')->first();
        $locationdata = DB::table('locations')->get();
        return view('amc.silver',compact('amcdata','locationdata'))->with('id',$id)->with('name',$name);
    }
    public function bronze(){
        $id=0;
        $name='';
        if(Auth::check()){
            $id = Auth::user()->id;
            $name = Auth::user()->name;
        }
        $amcdata = DB::table('amc_services')->select(DB::raw('GROUP_CONCAT(services.service_name) as service_name,GROUP_CONCAT(amc_services.price) as price,GROUP_CONCAT(amc_services.visits) as visits,amcs.no_of_services'))->leftJoin('services', 'services.id', '=', 'amc_services.service_id')->leftJoin('amcs', 'amcs.id', '=', 'amc_services.amc_id')->where('amc_services.amc_id','=',4)->groupBy('amc_services.amc_id')->orderBy('amc_services.amc_id', 'ASC')->first();
        $locationdata = DB::table('locations')->get();
        return view('amc.bronze',compact('amcdata','locationdata'))->with('id',$id)->with('name',$name);
    }
    public function sendpassword(Request $request)
    {
        $request = $request->all();
        $email = strtolower($request['email']);
        $token = bin2hex(openssl_random_pseudo_bytes(32));
        $date = date('Y-m-d H:i:s');
        //check in user table
        $res = DB::table('users')->where('email','=',$email)->first();
        if($res){
            //check the email is in password table
            $res = DB::table('password_resets')->where('email','=',$email)->first();
            if($res)
                DB::table('password_resets')->where('email', $email)->update(['token' => $token,'created_at'=>$date]);
            else
                DB::table('password_resets')->insert(array('email'=>$email,'token'=>$token,'created_at'=>$date));

            $to      = $email;
            $subject = 'Reset Password from Facilitz';
            $message = '<table width="100%"><tr><td><img style="width:100%" src="'.url().'/facilitiz/img/header.png"></td></tr><tr><td>Dear Sir/Madam,<br></td></tr>
            <tr><td>Please <a href="'.url().'/password/reset/'.$token.'">click here </a>to reset your password<td></tr>
            <tr><td><br>--</td></tr>
            <tr><td>Thanks & regards,</td></tr>
            <tr><td>Facilitz Concierge Services Pvt. Ltd.</td></tr>
            <tr><td>E-Mail: sales@facilitz.com</td></tr>
            <tr><td>Website: www.facilitz.com</td></tr>
            <tr><td><br>-----------------------------</td></tr>
            <tr><td>Note: This is an auto generated mail. Please do not reply to this mail as it will not be responded or attended. Kindly contact in the mail ID given in signature line.</td></tr>
            <tr><td><img style="width:100%" src="'.url().'/facilitiz/img/footer.png"></td></tr>
            </table>';
            
            $headers  = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $headers .= 'From: career@facilitz.com' . "\r\n";
            mail($to, $subject, $message, $headers);

            return redirect('/password')->with('status','Reset Password link successfully sent to your email id');
        }
        else
            return redirect('/password')->withErrors(["We can't find a user with that e-mail address."]);
    }
    public function sendmessage(Request $request)
    {
        $request = $request->all();
        $request['email'] = strtolower($request['email']);
        if($request){
            if($request['email']){
                Messages::create($request);
                $to      = $request['email'];
                $subject = 'Contact us from Facilitz';
                $message = '<table width="100%"><tr><td><img style="width:100%" src="'.url().'/facilitiz/img/header.png"></td></tr><tr><td>Dear Sir/Madam,<br></td></tr>
                <tr><td>Thank you for contact us. We will get back you soon.<td></tr>
                <tr><td><br>--</td></tr>
                <tr><td>Thanks & regards,</td></tr>
                <tr><td>Facilitz Concierge Services Pvt. Ltd.</td></tr>
                <tr><td>E-Mail: sales@facilitz.com</td></tr>
                <tr><td>Website: www.facilitz.com</td></tr>
                <tr><td><br>-----------------------------</td></tr>
                <tr><td>Note: This is an auto generated mail. Please do not reply to this mail as it will not be responded or attended. Kindly contact in the mail ID given in signature line.</td></tr>
                <tr><td><img style="width:100%" src="'.url().'/facilitiz/img/footer.png"></td></tr>
                </table>';
                
                $headers  = 'MIME-Version: 1.0' . "\r\n";
                $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                $headers .= 'From: career@facilitz.com' . "\r\n";
                mail($to, $subject, $message, $headers);
            }
        }
        return redirect('/')->with('status','Thank you for contact us. We will contact you soon!');
    }
    public function savenewlocation(Request $request)
    {
        $request = $request->all();
        if($request){
            RequestLocations::create($request);            
            if(Auth::check()){
                $email = Auth::user()->email;
            }
            else{
                $email= $request['email'];
            }
            $to      = $email;
            $subject = 'Location Request';
            $message = '<table width="100%"><tr><td><img style="width:100%" src="'.url().'/facilitiz/img/header.png"></td></tr><tr><td>Dear Sir/Madam,<br></td></tr>
            <tr><td>Thank you for your feedback. We will coming soon your location.<td></tr>
            <tr><td><br>--</td></tr>
            <tr><td>Thanks & regards,</td></tr>
            <tr><td>Facilitz Concierge Services Pvt. Ltd.</td></tr>
            <tr><td>E-Mail: sales@facilitz.com</td></tr>
            <tr><td>Website: www.facilitz.com</td></tr>
            <tr><td><br>-----------------------------</td></tr>
            <tr><td>Note: This is an auto generated mail. Please do not reply to this mail as it will not be responded or attended. Kindly contact in the mail ID given in signature line.</td></tr>
            <tr><td><img style="width:100%" src="'.url().'/facilitiz/img/footer.png"></td></tr>
            </table>';
            
            $headers  = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $headers .= 'From: career@facilitz.com' . "\r\n";
            mail($to, $subject, $message, $headers);
        }
        return redirect('/amc')->with('status','Thank you for feedback. Your location will coming soon');
    }
}
