<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
use App\User;
use App\Billings;
use App\Quotations;

Route::controllers([
    'auth' => 'Auth\AuthController',
    'password' => 'Auth\PasswordController',
]);
Route::get('auth/login',function(){
	//return Redirect::to('/');
    return view('facilitiz.login');
});
Route::get('login',function(){
    if(Auth::check())
        return Redirect::to('/dashboard');
    else
        return view('facilitiz.login');
});
Route::get('savevehiclewash','DailyservicesController@savevehiclewash');
Route::post('savevehiclewash','DailyservicesController@savevehiclewash');
Route::resource('vehiclewash','IndexController@vehiclewash');

Route::get('password',function(){
    $id=0;
    $name='';
    if(Auth::check()){
        return Redirect::to('/');
    }
    return view('auth.password')->with('id',$id)->with('name',$name);
    //echo bin2hex(openssl_random_pseudo_bytes(32));
});
Route::post('savenewlocation','IndexController@savenewlocation');
Route::post('sendmessage','IndexController@sendmessage');
Route::get('termsandconditions',function(){
    return view('facilitiz.terms');
});
Route::get('amcterms',function(){
    return view('facilitiz.amcterms');
});
Route::get('serviceterms',function(){
    return view('facilitiz.serviceterms');
});
Route::get('aboutus',function(){
    return view('facilitiz.aboutus');
});
Route::post('sendpassword','IndexController@sendpassword');
// Password reset link request routes...
Route::get('password/email', 'Auth\PasswordController@getEmail');
Route::post('password/email', 'Auth\PasswordController@postEmail');

// Password reset routes...
Route::get('password/reset/{token}', 'Auth\PasswordController@getReset');
Route::post('password/reset', 'Auth\PasswordController@postReset');

Route::get('/','IndexController@index');
Route::get('home','DashboardController@index');
Route::resource('contact','ContactController');
Route::post('savecontact','ContactController@save');
Route::resource('dashboard','DashboardController');
Route::post('changeworkstatus','DashboardController@changeworkstatus');
Route::post('saveprofile','DashboardController@saveprofile');
Route::get('admin',function(){
	return view('admin.index');
});
Route::post('loadpage','AdminController@loadpage');

Route::resource('blogs','BlogsController');
Route::post('saveblog','BlogsController@saveblog');
Route::post('changeblogstatus','BlogsController@changeblogstatus');
Route::post('deleteblog','BlogsController@deleteblog');

Route::post('savemiscellaneous','AdminController@savemiscellaneous');
Route::post('savequotation','AdminController@savequotation');
Route::post('savebilling','AdminController@savebilling');
Route::post('managebilling','AdminController@managebilling');
Route::post('saveexpenditure','AdminController@saveexpenditure');
Route::post('managequotation','AdminController@managequotation');
Route::post('saveamc','AdminController@saveamc');
Route::post('createuser','AdminController@createuser');

Route::resource('affiliate','AfliateController');
Route::post('saveafliaterequest','AfliateController@saveafliaterequest');

Route::resource('skilldevelopment','SkillController');
Route::post('saveskillrequest','SkillController@saveskillrequest');

Route::resource('amc','IndexController@amcview');
Route::post('saveamcrequest','AmcController@saveamcrequest');
Route::get('saveamcrequest','AmcController@saveamcrequest');
Route::post('sendservicerequest','AmcController@sendservicerequest');
Route::post('requestcomplete','AdminController@requestcomplete');
Route::get('diamond','IndexController@diamond');
Route::get('silver','IndexController@silver');
Route::get('bronze','IndexController@bronze');
Route::post('savecar','AdminController@savecar');
Route::post('deletecar','AdminController@deletecar');
Route::post('savelocation','AdminController@savelocation');
Route::post('deletelocation','AdminController@deletelocation');
Route::get('cart/{id}',function($id){
    if(Auth::check()){
        $email = Auth::user()->email;
        $name = Auth::user()->name;
        $phone = Auth::user()->contactno;
    }
    return view('amc.cart')->with('requestid',$id)->with('name',$name)->with('email',$email)->with('phone',$phone)->with('id',Auth::user()->id);
});
Route::post('savecart','AmcController@savecart');
Route::get('painting',function(){
	$id=0;
    $name='';
    if(Auth::check()){
        $id = Auth::user()->id;
        $name = Auth::user()->name;
    }
    return view('services.painting')->with('id',$id)->with('name',$name);
});
Route::get('electrician',function(){
	$id=0;
    $name='';
    if(Auth::check()){
        $id = Auth::user()->id;
        $name = Auth::user()->name;
    }
    return view('services.electrician')->with('id',$id)->with('name',$name);
});
Route::get('plumbing',function(){
	$id=0;
    $name='';
    if(Auth::check()){
        $id = Auth::user()->id;
        $name = Auth::user()->name;
    }
    return view('services.plumbing')->with('id',$id)->with('name',$name);
});
Route::get('carpentry',function(){
	$id=0;
    $name='';
    if(Auth::check()){
        $id = Auth::user()->id;
        $name = Auth::user()->name;
    }
    return view('services.carpentry')->with('id',$id)->with('name',$name);
});
Route::get('housekeeping',function(){
	$id=0;
    $name='';
    if(Auth::check()){
        $id = Auth::user()->id;
        $name = Auth::user()->name;
    }
    return view('services.housekeeping')->with('id',$id)->with('name',$name);
});
Route::get('civil',function(){
	$id=0;
    $name='';
    if(Auth::check()){
        $id = Auth::user()->id;
        $name = Auth::user()->name;
    }
    return view('services.civil')->with('id',$id)->with('name',$name);
});
Route::get('housecleaning',function(){
	$id=0;
    $name='';
    if(Auth::check()){
        $id = Auth::user()->id;
        $name = Auth::user()->name;
    }
    return view('services.housecleaning')->with('id',$id)->with('name',$name);
});
Route::get('pestcontrol',function(){
	$id=0;
    $name='';
    if(Auth::check()){
        $id = Auth::user()->id;
        $name = Auth::user()->name;
    }
    return view('services.pestcontrol')->with('id',$id)->with('name',$name);
});

Route::get('billpdf/{id}',function($id){
	$res = Billings::select('bill_no')->where('md5_bill_no','=',$id)->first();
	$billno = $res['bill_no'];
	$file=public_path().'/bills/'.$billno.'.pdf';
        return Response::download($file);
});
Route::get('quotationpdf/{id}',function($id){
	$res = Quotations::select('quotation_id')->where('md5_quotation_id','=',$id)->first();
	$billno = $res['quotation_id'];
	$file=public_path().'/quotations/'.$billno.'.pdf';
        return Response::download($file);
});

Route::get('testpdf',function(){
	// $data = array();
	// Mail::send('welcome', $data, function ($message) {
	//     $message->from('career@facilitz.com', 'Laravel');
	//     $message->to('sridhars151@gmail.com')->cc('sridhars@live.com');
	// });
    
});

Route::get('gapi/{name}',function($name){
	$tmp = array();
	$json =file_get_contents("https://maps.googleapis.com/maps/api/place/autocomplete/json?input=".$name."&types=geocode&key=AIzaSyAMlD9scNllibFtfSVjtD11xvnCQNy14PI");
	$json = json_decode($json);
	$result = $json->{'predictions'};
	for ($i=0; $i < sizeof($result); $i++) { 
	  $tmp[]=$result[$i]->{'description'};
	}
	echo json_encode($tmp);
});
Route::get('test',function(){
    $userdata = User::where('id','=',Auth::user()->id)->first();
    print_r($userdata);
    echo url();

	//echo $_SERVER['DOCUMENT_ROOT'];
	exit;
	$data = array(
'servicecase_id' => '1',
);
	$pdf = PDF::loadView('welcome', $data)->save('quotations/pdfname.pdf');
//return $pdf->download('invoice.pdf');
// http://laravel.io/forum/02-19-2014-need-to-mail-dynamically-created-pdf
	//http://webcheatsheet.com/php/send_email_text_html_attachment.php
});

// Redirect to facebook to authenticate
Route::get('facebook', 'AccountController@facebook_redirect');
Route::get('account/facebook', 'AccountController@facebook');

Route::get('linkedin', 'AccountController@linkedin_redirect');
Route::get('account/linkedin', 'AccountController@linkedin');

Route::get('google', 'AccountController@google_redirect');
Route::get('account/google', 'AccountController@google');

Route::get('twitter', 'AccountController@twitter_redirect');
Route::get('account/twitter', 'AccountController@twitter');
