<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AmcRequested extends Model
{
    protected $fillable = ['request_id','user_id','service_id'];
}
