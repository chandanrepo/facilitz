<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QuotationParticulars extends Model
{
    protected $fillable = ['quotation_id','col1','col2','col3','col4','col5'];
}
