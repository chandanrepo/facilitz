<?php



namespace App;



use Illuminate\Database\Eloquent\Model;



class Quotations extends Model

{

    protected $fillable = ['quotation_id','md5_quotation_id','quotation_date','service_id','from_address','to_address','to_email','additional_desc','payment_policy','warranty_desc','table_col1','table_col2','table_col3','table_col4','table_col5','total_amount','to_company_name','to_mobile','work_status','completion_date','progress'];

}

