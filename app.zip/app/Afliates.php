<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Afliates extends Model
{
    protected $fillable = ['first_name','last_name','voter_id','passport_id','driving_id','pan_card','service_id','business_type','total_area','mobile_no','email_id','details'];
}
