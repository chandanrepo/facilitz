<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contact extends Model
{
    protected $fillable = ['services','email','phone','log_date','location','work_status','user_id'];
}
