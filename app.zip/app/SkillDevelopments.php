<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SkillDevelopments extends Model
{
    protected $fillable = ['first_name','last_name','middle_name','nick_name','organization_type','organization_other','organization_ngo','dob','permanent_address','current_address','mobile_no','email_id','bpl_file_name','adhar_file_name','ref_id'];
}
