<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AmcRequestServices extends Model
{
    protected $fillable = ['request_id','amc_id','service_id','price','visits','balance_visit'];
}
