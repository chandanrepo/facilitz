<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VehilclewashTypeMapping extends Model
{
    protected $fillable = ['vehiclewash_id','car_type_id','no_of_cars','amount'];
}
