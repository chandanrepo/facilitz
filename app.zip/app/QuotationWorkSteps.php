<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QuotationWorkSteps extends Model
{
    protected $fillable = ['quotation_id','steps'];
}
