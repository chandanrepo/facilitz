<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AmcCarts extends Model
{
    protected $fillable = ['request_id','name','email','phone','address'];
}
