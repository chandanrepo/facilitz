<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AmcCompleted extends Model
{
    protected $fillable = ['amc_id','request_id','service_id','completed_date','comments'];
}
