<?php



namespace App;



use Illuminate\Database\Eloquent\Model;



class Billings extends Model

{

    protected $fillable = ['quotation_id','bill_no','md5_bill_no','total_amount','amount_paid','pending_amount','company_name','work_status','completion_date'];

}

