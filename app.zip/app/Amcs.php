<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Amcs extends Model
{
    protected $fillable = ['amc_type','no_of_services'];
}
