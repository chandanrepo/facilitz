<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AmcRequests extends Model
{
    protected $fillable = ['amc_id','user_id','no_of_visit','total_price','balance_visit','location'];
}
