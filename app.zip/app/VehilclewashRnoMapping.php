<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VehilclewashRnoMapping extends Model
{
    protected $fillable = ['vehiclewash_id','rno'];
}
