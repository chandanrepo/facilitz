<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AmcServices extends Model
{
    protected $fillable = ['amc_id','service_id','price','visits'];
}
