<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AmcRange extends Model
{
    protected $fillable = ['amc_id','range_from','range_to','no_of_visit'];
}
