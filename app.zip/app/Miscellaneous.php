<?php



namespace App;



use Illuminate\Database\Eloquent\Model;



class Miscellaneous extends Model

{

    protected $fillable = ['company_name','address','phone','mobile','email','websiteurl','beneficiary_name','bank','branch','account_number','ifsc_code','cin','payment_policy','pan'];

}

