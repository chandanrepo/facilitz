<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Expenditures extends Model
{
    protected $fillable = ['quotation_id','description','amount','exp_date'];
}
