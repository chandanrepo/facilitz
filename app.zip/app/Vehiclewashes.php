<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Vehiclewashes extends Model
{
    protected $fillable = ['user_id','total_amount','month','valid_till','grand_total'];
}
