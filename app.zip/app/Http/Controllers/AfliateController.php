<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use Auth;
use Illuminate\Support\Facades\Input;
use App\Students;
use Validator;
use Redirect;
use App\Afliates;
class AfliateController extends Controller
{
    public function __construct()
    {
        //$this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        $id=0;
        $name='';
        if(Auth::check()){
            $id = Auth::user()->id;
            $name = Auth::user()->name;
        }
        $servicedata = DB::table('services')->get();
        return view('afliate.index',compact('servicedata'))->with('id',$id)->with('name',$name);    
    }
    public function saveafliaterequest(Request $request){
        $data = $request->all();
        if($data){
            $res = Afliates::create($data);
            $id = $res->{'id'};
            $phone = $data['mobile_no'];
            $to = $data['email_id'];

            $subject = 'Affiliate request ';
            $message = '<table width="100%"><tr><td><img style="width:100%" src="'.url().'/facilitiz/img/header.png"></td></tr><tr><td>Dear Sir/Madam,<br>Your affiliate ref. no. is '.$id.'.Your relationship manager is Sonia with contact no. 1234567890. <td></tr>
            <tr><td><br>--</td></tr>
            <tr><td>Thanks & regards,</td></tr>
            <tr><td>Facilitz Concierge Services Pvt. Ltd.</td></tr>
            <tr><td>E-Mail: sales@facilitz.com</td></tr>
            <tr><td>Website: www.facilitz.com</td></tr>
            <tr><td><br>-----------------------------</td></tr>
            <tr><td>Note: This is an auto generated mail. Please do not reply to this mail as it will not be responded or attended. Kindly contact in the mail ID given in signature line.</td></tr>
            <tr><td><img style="width:100%" src="'.url().'/facilitiz/img/footer.png"></td></tr>
            </table>';         
            $headers  = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $headers .= 'From: services@facilitz.com' . "\r\n";
            mail($to, $subject, $message, $headers);

            if(preg_match("/^([0-9]){10}?$/", $phone)){
                $msg = "Dear Sir/Madam, Your affiliate ref. no. is ".$id.".Your relationship manager is Sonia with contact no. 1234567890. Regards, www.facilitz.com";
                $msg = rawurlencode($msg);
                $url = "http://www.smsjust.com/sms/user/urlsms.php?username=facilitz&pass=sms@facilitz123&senderid=FACLTZ&dest_mobileno=91".$phone."&message=".$msg."&response=Y";
                // Create a curl handle
                $ch = curl_init($url);
                // Execute
                curl_exec($ch);
                // Close handle
                curl_close($ch);
            }
            return redirect('affiliate')->with('status', 'Your request accepted successfully. We sent email regarding this. Our team will contact you soon.');
        }else{
            return Redirect::to('/affiliate');
        }     
    }
}