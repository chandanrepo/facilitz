<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use Auth;
use Illuminate\Support\Facades\Input;
use App\AmcRequests;
use App\AmcRequested;
use Redirect;
use App\AmcCarts;
class AmcController extends Controller
{
    public function __construct()
    {
        //$this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        $id=0;
        $name='';
        if(Auth::check()){
            $id = Auth::user()->id;
            $name = Auth::user()->name;
        }
        $amcdata = DB::table('amcs')->select(DB::raw('GROUP_CONCAT(services.service_name) as service_name,GROUP_CONCAT(amc_services.price) as price,GROUP_CONCAT(amc_services.visits) as visits,amcs.no_of_services'))->leftJoin('amc_services', 'amcs.id', '=', 'amc_services.amc_id')->leftJoin('services', 'services.id', '=', 'amc_services.service_id')->groupBy('amc_services.amc_id')->orderBy('amc_services.amc_id', 'ASC')->get();
        $servicedata = DB::table('amc_services')->leftJoin('services', 'amc_services.service_id', '=', 'services.id')->where('amc_services.amc_id','=',1)->get(array('amc_services.*','services.service_name'));
        return view('amc.index',compact('servicedata','amcdata'))->with('id',$id)->with('name',$name);     
    }
    public function saveamcrequest(Request $request){
        $data = $request->all();
        $date = date('Y-m-d H:i:s');
        $amcid = $data['id'];
        $email = '';
        $name = '';
        $phone = '';
        $userid = 0;
        if(Auth::check()){
            $email = Auth::user()->email;
            $name = Auth::user()->name;
            $phone = Auth::user()->contactno;
            $userid = Auth::user()->id;
        }

        $amcdata = DB::table('amcs')->where('id','=',$amcid)->first();
        $amcservices = DB::table('amc_services')->where('amc_id','=',$amcid)->get();
        if($amcid!=1){
            $insarray = array('amc_id'=>$amcid,'user_id'=>$userid,'no_of_visit'=>$amcdata->no_of_services,'balance_visit'=>$amcdata->no_of_services,'location'=>$data['location']);
            $res = AmcRequests::create($insarray);
            $requestid = $res->{'id'};

            $qarray = array();
            $total = 0;
            foreach ($amcservices as $key => $value) {
                $total = $total+$value->price;
                $qarray[] = array('request_id'=>$requestid,'amc_id'=>$amcid,'service_id'=>$value->service_id,'price'=>$value->price,'visits'=>$value->visits,'balance_visit'=>$value->visits,'created_at'=>$date);
            }
            if(sizeof($qarray)>0)
                DB::table('amc_request_services')->insert($qarray);
        }
        else{
            $total = $data['total'];
            $insarray = array('amc_id'=>$amcid,'user_id'=>$userid,'no_of_visit'=>$data['visit'],'balance_visit'=>$data['visit']);
            $res = AmcRequests::create($insarray);
            $requestid = $res->{'id'};

            $qarray = array();
            $serviceid = explode(',',$data['serviceid']);
            for ($i=0; $i < sizeof($serviceid) ; $i++) {
                foreach ($amcservices as $key => $value) {
                    if($value->service_id==$serviceid[$i]){
                        $price = $value->price;
                        $visit = $value->visits;
                    }
                }
                $qarray[] = array('request_id'=>$requestid,'amc_id'=>$amcid,'service_id'=>$serviceid[$i],'price'=>$price,'visits'=>$visit,'balance_visit'=>$visit,'created_at'=>$date);
            }
            if(sizeof($qarray)>0)
                DB::table('amc_request_services')->insert($qarray);
        }

        $update = AmcRequests::where('id','=',$requestid)->first();
        $update->fill(array('total_price'=>$total))->save();
        //return redirect('/dashboard')->with('status', 'Your request Submitted successfully!');
        return view('amc.cart')->with('requestid',$requestid)->with('name',$name)->with('email',$email)->with('phone',$phone)->with('id',$userid);
        //return redirect('/cart/'.$requestid);
    }
    public function sendservicerequest(Request $request)
    {
        $request = $request->all();
        $userid = Auth::user()->id;
        $check = AmcRequested::where('request_id','=',$request['request_id'])->where('service_id','=',$request['service_id'])->where('user_id','=',$userid)->first();
        if($check){
            echo json_encode(array('status'=>'fail'));
        }
        else{
            $insarray = array('request_id'=>$request['request_id'],'user_id'=>$userid,'service_id'=>$request['service_id']);
            $res = AmcRequested::create($insarray);
            $requestid = $res->{'id'};

            $to = Auth::user()->email;
            $subject = 'AMC Request';
            //$message = 'Dear Sir/Madam,<br>Your bill no:'.$billname.' w.r.t. quotation ref. no: '.$quotation_id.'<br><a href="'.$qurl.'">Click here to view you bill</a>'; 
            $message = '<table width="100%"><tr><td><img style="width:100%" src="'.url().'/facilitiz/img/header.png"></td></tr><tr><td>Dear Sir/Madam,<br></td></tr>
                <tr><td>Greetings from Facilitz Concierge Services Pvt. Ltd. We have received your AMC request. Your AMC service request ID is: '.$requestid.' <td></tr>
                <tr><td><br>Our operator will contact you shortly.</td></tr>
                <tr><td><br>--</td></tr>
                <tr><td>Thanks & regards,</td></tr>
                <tr><td>Facilitz Concierge Services Pvt. Ltd.</td></tr>
                <tr><td>E-Mail: sales@facilitz.com</td></tr>
                <tr><td>Website: www.facilitz.com</td></tr>
                <tr><td><br>-----------------------------</td></tr>
                <tr><td>Note: This is an auto generated mail. Please do not reply to this mail as it will not be responded or attended. Kindly contact in the mail ID given in signature line.</td></tr>
                <tr><td><img style="width:100%" src="'.url().'/facilitiz/img/footer.png"></td></tr>
                </table>';             
            $headers  = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $headers .= 'From: services@facilitz.com' . "\r\n";
            mail($to, $subject, $message, $headers);

            $phone = Auth::user()->contactno;
            if(preg_match("/^([0-9]){10}?$/", $phone)){
                $msg = "Dear Sir/Madam, Your AMC service request ID is: ".$requestid.". Our operator will contact you shortly. Regards, www.facilitz.com";
                $msg = rawurlencode($msg);
                $url = "http://www.smsjust.com/sms/user/urlsms.php?username=facilitz&pass=sms@facilitz123&senderid=FACLTZ&dest_mobileno=91".$phone."&message=".$msg."&response=Y";
                // Create a curl handle
                $ch = curl_init($url);
                // Execute
                curl_exec($ch);
                // Close handle
                curl_close($ch);
            }
            echo json_encode(array('status'=>'success'));
        }
    }
    public function diamond(){
        $id=0;
        $name='';
        if(Auth::check()){
            $id = Auth::user()->id;
            $name = Auth::user()->name;
        }
        $amcdata = DB::table('amc_services')->select(DB::raw('GROUP_CONCAT(services.service_name) as service_name,GROUP_CONCAT(amc_services.price) as price,GROUP_CONCAT(amc_services.visits) as visits,amcs.no_of_services'))->leftJoin('services', 'services.id', '=', 'amc_services.service_id')->leftJoin('amcs', 'amcs.id', '=', 'amc_services.amc_id')->where('amc_services.amc_id','=',2)->groupBy('amc_services.amc_id')->orderBy('amc_services.amc_id', 'ASC')->first();
        return view('amc.diamond',compact('amcdata'))->with('id',$id)->with('name',$name);
    }
    public function silver(){
        $id=0;
        $name='';
        if(Auth::check()){
            $id = Auth::user()->id;
            $name = Auth::user()->name;
        }
        $amcdata = DB::table('amc_services')->select(DB::raw('GROUP_CONCAT(services.service_name) as service_name,GROUP_CONCAT(amc_services.price) as price,GROUP_CONCAT(amc_services.visits) as visits,amcs.no_of_services'))->leftJoin('services', 'services.id', '=', 'amc_services.service_id')->leftJoin('amcs', 'amcs.id', '=', 'amc_services.amc_id')->where('amc_services.amc_id','=',3)->groupBy('amc_services.amc_id')->orderBy('amc_services.amc_id', 'ASC')->first();
        return view('amc.silver',compact('amcdata'))->with('id',$id)->with('name',$name);
    }
    public function bronze(){
        $id=0;
        $name='';
        if(Auth::check()){
            $id = Auth::user()->id;
            $name = Auth::user()->name;
        }
        $amcdata = DB::table('amc_services')->select(DB::raw('GROUP_CONCAT(services.service_name) as service_name,GROUP_CONCAT(amc_services.price) as price,GROUP_CONCAT(amc_services.visits) as visits,amcs.no_of_services'))->leftJoin('services', 'services.id', '=', 'amc_services.service_id')->leftJoin('amcs', 'amcs.id', '=', 'amc_services.amc_id')->where('amc_services.amc_id','=',4)->groupBy('amc_services.amc_id')->orderBy('amc_services.amc_id', 'ASC')->first();
        return view('amc.bronze',compact('amcdata'))->with('id',$id)->with('name',$name);
    }
    public function savecart(Request $request)
    {
        $request = $request->all();
        if($request){
            $requestid = $request['request_id'];
            AmcCarts::create($request);
            $to = $request['email'];
            $subject = 'AMC Signup';
            //$message = 'Dear Sir/Madam,<br>Your bill no:'.$billname.' w.r.t. quotation ref. no: '.$quotation_id.'<br><a href="'.$qurl.'">Click here to view you bill</a>'; 
            $message = '<table width="100%"><tr><td><img style="width:100%" src="'.url().'/facilitiz/img/header.png"></td></tr><tr><td>Dear Sir/Madam,<br></td></tr>
                <tr><td>Greetings from Facilitz Concierge Services Pvt. Ltd. We have prepared your AMC with AMC ID: '.$requestid.' <td></tr>
                <tr><td><br>Please click here to view your Annual Maintenance Contract(AMC).</td></tr>
                <tr><td><br>Please feel free to discuss with us if you have any queries. We hope to serve you better with positive enduring commitment in years to come.</td></tr>
                <tr><td><br>--</td></tr>
                <tr><td>Thanks & regards,</td></tr>
                <tr><td>Facilitz Concierge Services Pvt. Ltd.</td></tr>
                <tr><td>E-Mail: sales@facilitz.com</td></tr>
                <tr><td>Website: www.facilitz.com</td></tr>
                <tr><td><br>-----------------------------</td></tr>
                <tr><td>Note: This is an auto generated mail. Please do not reply to this mail as it will not be responded or attended. Kindly contact in the mail ID given in signature line.</td></tr>
                <tr><td><img style="width:100%" src="'.url().'/facilitiz/img/footer.png"></td></tr>
                </table>';             
            $headers  = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $headers .= 'From: services@facilitz.com' . "\r\n";
            mail($to, $subject, $message, $headers);

            $phone = $request['phone'];
            if(preg_match("/^([0-9]){10}?$/", $phone)){
                $msg = "Your AMC is prepared with AMC ID: ".$requestid." and is mailed to your e-mail id. Kindly check your mail. Regards, www.facilitz.com";
                $msg = rawurlencode($msg);
                $url = "http://www.smsjust.com/sms/user/urlsms.php?username=facilitz&pass=sms@facilitz123&senderid=FACLTZ&dest_mobileno=91".$phone."&message=".$msg."&response=Y";
                // Create a curl handle
                $ch = curl_init($url);
                // Execute
                curl_exec($ch);
                // Close handle
                curl_close($ch);
            }
        }
        return redirect('/amc')->with('status','Thank you for choosing AMC. We will get back you soon');
    }
}