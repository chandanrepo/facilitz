<?php 
namespace App\Http\Controllers;
//namespace App\Http\Controllers\Auth;
use Redirect;
use Socialize;
use DB;
use App\User;
use Auth;
class AccountController extends Controller {
  // To redirect github
  public function facebook_redirect() {
    return Socialize::with('facebook')->redirect();
  }
  // to get authenticate user data
  public function facebook() {
    $user = Socialize::with('facebook')->user();
    // Do your stuff with user data.
    //print_r($user);die;
    // Check user already exists
    $password = '123456';
    $email = $user->{'email'};
    $users = User::where('email','=',$email)->first();
    if($users === null){
      $password = bcrypt('123456');
      $maxid = DB::table('users')->max('id');
      $id = $maxid+1;
      $cols = array('id'=>$id,'email' => $email, 'name' => $user->{'name'},'password'=>$password);
      User::create($cols);
    }
    else{
      //update
      $password = bcrypt('123456');
      $input = array('password'=>$password);
      $users->fill($input)->save();
    }
    
    // print_r($user);die;
    if(!Auth::check()){
      if (Auth::attempt(array('email' => $email, 'password' => '123456')))
      {
        // The user is active, not suspended, and exists.
        //$userid = Auth::user()->id;
      }
    }
    return Redirect::intended('/');
  }
  public function linkedin_redirect() {
    return Socialize::with('linkedin')->redirect();
  }
  // to get authenticate user data
  public function linkedin() {
    if(isset($_REQUEST['error'])=='access_denied'){
      return Redirect::intended('/');
    }
    $user = Socialize::with('linkedin')->user();
    // Do your stuff with user data.
    //print_r($user);die;
    // Check user already exists
    $password = '123456';
    $email = $user->{'email'};
    $users = User::where('email','=',$email)->first();
    if($users === null){
      $password = bcrypt('123456');
      $maxid = DB::table('users')->max('id');
      $id = $maxid+1;
      $cols = array('id'=>$id,'email' => $email, 'name' => $user->{'name'},'password'=>$password);
      User::create($cols);
    }
    else{
      //update
      $password = bcrypt('123456');
      $input = array('password'=>$password);
      $users->fill($input)->save();
    }
    
    // print_r($user);die;
    if(!Auth::check()){
      if (Auth::attempt(array('email' => $email, 'password' => '123456')))
      {
        // The user is active, not suspended, and exists.
        //$userid = Auth::user()->id;
      }
    }
    return Redirect::intended('/');
  }
  public function google_redirect() {
    return Socialize::with('google')->redirect();
  }
  // to get authenticate user data
  public function google() {
    $user = Socialize::with('google')->user();
    // Check user already exists
    $password = '123456';
    $email = $user->{'email'};
    $users = User::where('email','=',$email)->first();
    if($users === null){
      $password = bcrypt('123456');
      $maxid = DB::table('users')->max('id');
      $id = $maxid+1;
      $cols = array('id'=>$id,'email' => $email, 'name' => $user->{'name'},'password'=>$password);
      User::create($cols);
    }
    else{
      //update
      $password = bcrypt('123456');
      $input = array('password'=>$password);
      $users->fill($input)->save();
    }
    
    // print_r($user);die;
    if(!Auth::check()){
      if (Auth::attempt(array('email' => $email, 'password' => '123456')))
      {
        // The user is active, not suspended, and exists.
        //$userid = Auth::user()->id;
      }
    }
    return Redirect::intended('/');
  }
  public function twitter_redirect() {
    return Socialize::with('twitter')->redirect();
  }
  // to get authenticate user data
  public function twitter() {
    return Redirect::intended('/');
    exit;
    $user = Socialize::with('twitter')->user();
    // Do your stuff with user data.
    print_r($user);die;
    // Check user already exists
    $password = '123456';
    $email = $user->{'email'};
    $users = User::where('email','=',$email)->first();
    if($users === null){
      $password = bcrypt('123456');
      $maxid = DB::table('users')->max('id');
      $id = $maxid+1;
      $cols = array('id'=>$id,'email' => $email, 'name' => $user->{'name'},'password'=>$password);
      User::create($cols);
    }
    else{
      //update
      $password = bcrypt('123456');
      $input = array('password'=>$password);
      $users->fill($input)->save();
    }
    
    // print_r($user);die;
    if(!Auth::check()){
      if (Auth::attempt(array('email' => $email, 'password' => '123456')))
      {
        // The user is active, not suspended, and exists.
        //$userid = Auth::user()->id;
      }
    }
    return Redirect::intended('/');
  }




}