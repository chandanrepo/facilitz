<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use App\Blogs;
use Auth;
use Illuminate\Support\Facades\Input;
class BlogsController extends Controller
{
    public function __construct()
    {
        //$this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        $id=0;
        $name='';
        if(Auth::check()){
            $id = Auth::user()->id;
            $name = Auth::user()->name;
        }
        $blogdata = Blogs::leftJoin('users', 'blogs.created_by', '=', 'users.id')->where('flag','=','1')->orderBy('id', 'DESC')->paginate(5,array('blogs.*','users.name'));
        return view('blogs.index',compact('blogdata'))->with('id',$id)->with('name',$name);     
    }
    public function saveblog(Request $request){
        if(Auth::check()){
        $data = $request->all();
        $fileName='';
        $input = array();
        if (Input::hasFile('image'))
        {
            if (Input::file('image')->isValid())
            {
                $extension = Input::file('image')->getClientOriginalExtension(); // getting image extension
                $fileTypes = array('jpg','jpeg','gif','png');
                if (in_array(strtolower($extension),$fileTypes)) { 
                    $fileName = str_random(32) . '.' . $extension; // renameing image
                    $destinationPath = public_path('/img/blogs');
                    Input::file('image')->move($destinationPath, $fileName);
                    $input['image_name'] = $fileName;
                    $data['hidimagename'] = $fileName;
                }
            }
        }
        $id = Auth::user()->id;
        $input['title']=$data['title'];
        $input['description']=$data['description'];
        if($data['hidid']!=''){
            if($data['hidimagename']==''){
                $input['image_name']='';
            }
            $blog = Blogs::where('id','=',$data['hidid'])->first();
            $blog->fill($input)->save();
        }
        else{
            $input['created_by']=$id;
            Blogs::create($input);
        } 
        }       
    }
    public function changeblogstatus(Request $request){
        if(Auth::check()){
        $data = $request->all();
        //print_r($data);
        $input = array('flag'=>$data['status']);
        $blog = Blogs::where('id','=',$data['id'])->first();
        $blog->fill($input)->save();
        }
    }
    public function deleteblog(Request $request){
        if(Auth::check()){
        $data = $request->all();
        $id=$data['id'];
        DB::table('blogs')->where('id', '=',$id)->delete();
        }
    }
}