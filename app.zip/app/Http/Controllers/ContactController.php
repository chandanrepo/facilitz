<?php

namespace App\Http\Controllers;

use App\Contact;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;
class ContactController extends Controller
{
    public function __construct()
    {
        
    }
    public function save(Request $request)
    {
        $input = array();
        $email = $request['email'];
        $user_id=0;
        if(Auth::check()){
            $user_id = Auth::user()->id;
            $email = Auth::user()->email;
        }   
        if($request['services']!='' && $email!='' & $request['phone']!=''){
          $input['services'] = $request['services'];
          $input['user_id'] = $user_id;
            $input['email'] = $email;
            $input['phone'] = $request['phone'];
            $input['location'] = $request['location'];
            $res = Contact::create($input);  
            $rid = $res->{'id'};

            //mail to user
            $to      = $email.', ';
            //$to .= 'wez@example.com';
            $subject = 'Get request';
            $message = '<table width="100%"><tr><td><img style="width:100%" src="'.url().'/facilitiz/img/header.png"></td></tr><tr><td>Dear Sir/Madam,<br></td></tr>
            <tr><td>Greetings from Facilitz Concierge Services Pvt. Ltd. With reference to your request received in our website, your request ID is: '.$rid.'<td></tr>
            <tr><td><br>Our operators will call you shortly.</td></tr>
            <tr><td><br>--</td></tr>
            <tr><td>Thanks & regards,</td></tr>
            <tr><td>Facilitz Concierge Services Pvt. Ltd.</td></tr>
            <tr><td>E-Mail: sales@facilitz.com</td></tr>
            <tr><td>Website: www.facilitz.com</td></tr>
            <tr><td><br>-----------------------------</td></tr>
            <tr><td>Note: This is an auto generated mail. Please do not reply to this mail as it will not be responded or attended. Kindly contact in the mail ID given in signature line.</td></tr>
            <tr><td><img style="width:100%" src="'.url().'/facilitiz/img/footer.png"></td></tr>
            </table>';
            
            $headers  = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $headers .= 'From: services@facilitz.com' . "\r\n";
            mail($to, $subject, $message, $headers);

            //mail to sales
            $to      = 'sales@facilitz.com';
            $subject = 'New request';
            $message = 'Hi,<br>Below details are from customer. <br>Work:'.$request['services'].'<br>Location:'.$request['location'].'<br>Phone:'.$request['phone'].'<br>Email:'.$request['email'].'<br>Requestid:'.$rid;
            
            $headers  = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $headers .= 'From: '.$email. "\r\n";
            mail($to, $subject, $message, $headers);

            //msg to user
            if(preg_match("/^([0-9]){10}?$/", $request['phone'])){
                $msg = "Dear Sir/Madam, Thank you for contacting us. You request ID is: ".$rid.". Our operator will contact you shortly. Regards, www.facilitz.com";
                $msg = rawurlencode($msg);
                $url = "http://www.smsjust.com/sms/user/urlsms.php?username=facilitz&pass=sms@facilitz123&senderid=FACLTZ&dest_mobileno=91".$request['phone']."&message=".$msg."&response=Y";
                // Create a curl handle
                $ch = curl_init($url);
                // Execute
                curl_exec($ch);
                // Close handle
                curl_close($ch);
            }
            //msg to sales team
                $msg = "Dear Sir/Madam, New request from customer. Mobile Number: ".$request['phone'].", Location: ".$request['location'].", Type of work: ".$request['services'].".";
                $msg = rawurlencode($msg);
                $url = "http://www.smsjust.com/sms/user/urlsms.php?username=facilitz&pass=sms@facilitz123&senderid=FACLTZ&dest_mobileno=919880492482,917022359481&message=".$msg."&response=Y";
                // Create a curl handle
                $ch = curl_init($url);
                // Execute
                curl_exec($ch);
                // Close handle
                curl_close($ch);
        }        
    }
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response

     */
    public function create()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return Response
     */
    public function store(Request $request)
    {
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($user_id)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($user_id)
    {
        
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
//        $user_id= Auth::user()->id;
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
        //
    }
}
