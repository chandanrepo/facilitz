<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

use DB;
use Auth;
use Illuminate\Http\Request;
use App\User;
use Hash;
use Illuminate\Support\Facades\Input;
use App\Services;
use App\Contact;
class WebserviceController extends Controller
{
    public function __construct(){
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, PUT, POST');
    }
    public function index(){
    }
    public function checklogin(Request $request){
        $request = $request->all();
        //$request=array('username'=>$REQUEST['username'],'password'=>$_REQUEST['password']);
        if (Auth::attempt(['email' => $request['username'], 'password' => $request['password']])) {
            $res = User::where('email','=',$request['username'])->first();
            if($res->id!=4)
                $result = array("status"=>1,"email"=>$res->email,"firstname"=>$res->name,"contactno"=>$res->contactno,"id"=>$res->id);
            else
                $result = array("status"=>0);
        }
        else{
            $result= array("status"=>0);
        }
        //$result= array("status"=>1,'firstname'=>"sre");
        echo json_encode($result);
    }
    public function facebooklogin(Request $request){
        $request = $request->all();
        $name = $request['name'];
        $email = $request['email'];
        $password = "123456";
        $password = bcrypt($password);
        //exit;
        $checkuser = User::where('email','=',$email)->first();
        if($checkuser){
            $result = array("status"=>1,"email"=>$checkuser->email,"firstname"=>$checkuser->name,"contactno"=>$checkuser->contactno,"id"=>$checkuser->id);
        }
        else{
            $res = User::create(array("email"=>$email,"name"=>$name,"password"=>$password));
            if($res){
                $result = array("status"=>1,"email"=>$email,"firstname"=>$name,"id"=>$res->id);
            }
            else{
                $result= array("status"=>0,"msg"=>"Registration failed");
            }
        }
        echo json_encode($result);
    }
    public function register(Request $request){
        $request = $request->all();
        $name = $request['name'];
        $email = $request['email'];
        $mobile = $request['mobile'];
        $password = $request['password'];
        $password = bcrypt($password);
        //exit;
        $checkuser = User::where('email','=',$email)->first();
        if($checkuser){
            $result= array("status"=>2,"msg"=>"Email already exists");
        }
        else{
            $res = User::create(array("email"=>$email,"name"=>$name,"contactno"=>$mobile,"password"=>$password));
            if($res){
                $id = $res->{'id'};
                $result= array("status"=>1,"msg"=>"Registration process completed successfully","firstname"=>$name,"email"=>$email,"id"=>$id);
            }
            else{
                $result= array("status"=>0,"msg"=>"Registration failed");
            }
        }
        echo json_encode($result);
    }
    public function services(Request $request){
        $request = $request->all();
        $res = Services::get();
        $result = array();
        foreach ($res as $key => $value) {
            $result[]= array("name"=>$value->service_name);
        }
        echo json_encode(array("stauts"=>1,"service"=>$result));
    }
    public function saverequest(Request $request)
    {
        $request = $request->all();
        $input = array();
        $email = $request['email'];
        $user_id=$request['user_id'];
        if($request['services']!='' && $email!='' & $request['phone']!=''){
          $input['services'] = $request['services'];
          $input['user_id'] = $user_id;
            $input['email'] = $email;
            $input['phone'] = $request['phone'];
            $input['location'] = $request['location'];
            
            $result= array("status"=>1,"msg"=>"Request submitted successfully");
            echo json_encode($result);
            //exit; 
            $res = Contact::create($input);
            $rid = $res->{'id'};

            //mail to user
            $to      = $email.', ';
            //$to .= 'wez@example.com';
            $subject = 'Get request';
            $message = '<table width="100%"><tr><td><img style="width:100%" src="'.url().'/facilitiz/img/header.png"></td></tr><tr><td>Dear Sir/Madam,<br></td></tr>
            <tr><td>Greetings from Facilitz Concierge Services Pvt. Ltd. With reference to your request received in our website, your request ID is: '.$rid.'<td></tr>
            <tr><td><br>Our operators will call you shortly.</td></tr>
            <tr><td><br>--</td></tr>
            <tr><td>Thanks & regards,</td></tr>
            <tr><td>Facilitz Concierge Services Pvt. Ltd.</td></tr>
            <tr><td>E-Mail: sales@facilitz.com</td></tr>
            <tr><td>Website: www.facilitz.com</td></tr>
            <tr><td><br>-----------------------------</td></tr>
            <tr><td>Note: This is an auto generated mail. Please do not reply to this mail as it will not be responded or attended. Kindly contact in the mail ID given in signature line.</td></tr>
            <tr><td><img style="width:100%" src="'.url().'/facilitiz/img/footer.png"></td></tr>
            </table>';
            
            $headers  = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $headers .= 'From: services@facilitz.com' . "\r\n";
            mail($to, $subject, $message, $headers);

            //mail to sales
            $to      = 'sales@facilitz.com';
            $subject = 'New request';
            $message = 'Hi,<br>Below details are from customer. <br>Work:'.$request['services'].'<br>Location:'.$request['location'].'<br>Phone:'.$request['phone'].'<br>Email:'.$request['email'].'<br>Requestid:'.$rid;
            
            $headers  = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $headers .= 'From: '.$email. "\r\n";
            mail($to, $subject, $message, $headers);

            //msg to user
            if(preg_match("/^([0-9]){10}?$/", $request['phone'])){
                $msg = "Dear Sir/Madam, Thank you for contacting us. You request ID is: ".$rid.". Our operator will contact you shortly. Regards, www.facilitz.com";
                $msg = rawurlencode($msg);
                $url = "http://www.smsjust.com/sms/user/urlsms.php?username=facilitz&pass=sms@facilitz123&senderid=FACLTZ&dest_mobileno=91".$request['phone']."&message=".$msg."&response=Y";
                // Create a curl handle
                $ch = curl_init($url);
                // Execute
                curl_exec($ch);
                // Close handle
                curl_close($ch);
            }
            //msg to sales team
                $msg = "Dear Sir/Madam, New request from customer. Mobile Number: ".$request['phone'].", Location: ".$request['location'].", Type of work: ".$request['services'].".";
                $msg = rawurlencode($msg);
                $url = "http://www.smsjust.com/sms/user/urlsms.php?username=facilitz&pass=sms@facilitz123&senderid=FACLTZ&dest_mobileno=919880492482,917022359481&message=".$msg."&response=Y";
                // Create a curl handle
                $ch = curl_init($url);
                // Execute
                curl_exec($ch);
                // Close handle
                curl_close($ch);
        }        
    }
    public function test(Request $request)
    {

        $request = $request->all();
        //$html = file_get_contents("http://bangalore.startups-list.com/");
        //$html = "<h1>dfdf</h1>";
        //Create a new DOM document
        $dom = new \DOMDocument();
         
        //Parse the HTML. The @ is used to suppress any parsing errors
        //that will be thrown if the $html string isn't valid XHTML.
        @$dom->loadHTML($html);
         
        //Get all links. You could also use any other tag name here,
        //like 'img' or 'table', to extract other tags.
        $links = $dom->getElementsByTagName('h1');
         
        //Iterate over the extracted links and display their URLs
        foreach ($links as $link){
            //Extract and show the "href" attribute. 
            echo $link->nodeValue, '<br>';
        }
    }
    public function getuserservicelist(Request $request){
        $request = $request->all();
        $id = $request['user_id'];
        $res = DB::table('contacts')->where('user_id','=',$id)->orderBy('id', 'DESC')->get();
        //$res = DB::table('contacts')->orderBy('id', 'DESC')->get();
        $result = array();
        foreach ($res as $key => $value) {
            $result[]= array("id"=>$value->id,"service_name"=>$value->services,"email"=>$value->email,"phone"=>$value->phone);
        }
        echo json_encode(array("stauts"=>1,"service"=>$result));
    }
}
