<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use Auth;
use Illuminate\Support\Facades\Input;
use App\CarTypes;
use Validator;
use Redirect;
use App\Vehiclewashes;
class DailyservicesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
            
    }
    public function savevehiclewash(Request $request){
        $data = $request->all();
        $date = date('Y-m-d H:i:s');
        $hidcartype = explode(',',$data['hidcartype']);
        $hidnoofcars = explode(',',$data['hidnoofcars']);
        $hidrno = explode(',',$data['hidrno']);
        $total_amount = $data['total_amount'];
        $grand_total = $data['hidtotal_amount'];
        $hidprice = explode(',',$data['hidprice']);
        $userid = Auth::user()->id;
        $email = Auth::user()->email;
        $date = date('Y-m-d H:i:s');
        if($total_amount>0){
            // insert into vehiclewash master table
            $input = array('user_id'=>$userid,'total_amount'=>$total_amount,'grand_total'=>$grand_total,'month'=>$data['hidmonth'],'valid_till'=>date("Y-m-d",strtotime($data['hidvalidtill'])));
            $res = Vehiclewashes::create($input);
            $vid = $res->{'id'};
            $typeinsarray=array();
            $rnoinsarray=array();
            for ($i=0; $i < sizeof($hidcartype) ; $i++) { 
                $typeinsarray[]=array('vehiclewash_id'=>$vid,'car_type_id'=>$hidcartype[$i],'no_of_cars'=>$hidnoofcars[$i],'amount'=>$hidprice[$i],'created_at'=>$date,'updated_at'=>$date);
                //registration number
                $tmp = explode('~',$hidrno[$i]);
                for ($j=0; $j < sizeof($tmp) ; $j++) { 
                    $rnoinsarray[]=array('vehiclewash_id'=>$vid,'rno'=>$tmp[$i],'created_at'=>$date,'updated_at'=>$date);
                }
            }
            if(sizeof($typeinsarray)>0)
                DB::table('vehilclewash_type_mapping')->insert($typeinsarray);
            if(sizeof($rnoinsarray)>0)
                DB::table('vehilclewash_rno_mapping')->insert($rnoinsarray);

            $to      = $email;
            $subject = 'Placing of car wash order';
            $message = '<table width="100%"><tr><td><img style="width:100%" src="'.url().'/facilitiz/img/header.png"></td></tr><tr><td>Dear Sir/Madam,<br></td></tr>
            <tr><td>Your car wash order placed successfully<td></tr>
            <tr><td><br>--</td></tr>
            <tr><td>Thanks & regards,</td></tr>
            <tr><td>Facilitz Concierge Services Pvt. Ltd.</td></tr>
            <tr><td>E-Mail: sales@facilitz.com</td></tr>
            <tr><td>Website: www.facilitz.com</td></tr>
            <tr><td><br>-----------------------------</td></tr>
            <tr><td>Note: This is an auto generated mail. Please do not reply to this mail as it will not be responded or attended. Kindly contact in the mail ID given in signature line.</td></tr>
            <tr><td><img style="width:100%" src="'.url().'/facilitiz/img/footer.png"></td></tr>
            </table>';
            
            $headers  = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $headers .= 'From: services@facilitz.com' . "\r\n";
            mail($to, $subject, $message, $headers);

            $to      = 'services@facilitz.com';
            $subject = 'Placing of car wash order';
            $message = '<table width="100%"><tr><td><img style="width:100%" src="'.url().'/facilitiz/img/header.png"></td></tr><tr><td>Dear Sir/Madam,<br></td></tr>
            <tr><td>New car wash order placed.<td></tr>
            <tr><td><br>--</td></tr>
            <tr><td>Thanks & regards,</td></tr>
            <tr><td>Facilitz Concierge Services Pvt. Ltd.</td></tr>
            <tr><td>E-Mail: sales@facilitz.com</td></tr>
            <tr><td>Website: www.facilitz.com</td></tr>
            <tr><td><br>-----------------------------</td></tr>
            <tr><td>Note: This is an auto generated mail. Please do not reply to this mail as it will not be responded or attended. Kindly contact in the mail ID given in signature line.</td></tr>
            <tr><td><img style="width:100%" src="'.url().'/facilitiz/img/footer.png"></td></tr>
            </table>';
            
            $headers  = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $headers .= 'From: '.$email. "\r\n";
            mail($to, $subject, $message, $headers);
        }
        return redirect('/vehiclewash')->with('status', 'Your request Submitted successfully!');
    }
}