<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Http\Controllers\Controller;

use DB;

use App\Contact;

use App\User;

use Auth;

class DashboardController extends Controller

{

    public function __construct()

    {

        $this->middleware('auth');

    }

    /**

     * Display a listing of the resource.

     *

     * @return Response

     */

    public function index()

    {

        $name = '';

        if(Auth::check()){

            $name = Auth::user()->name;

            $id = Auth::user()->id;
            $email = Auth::user()->email;

            if($id==4){

                $months = array();
                for ($i = 6; $i >= 0; $i--) {
                  array_push($months, date('Y-n', strtotime("-$i month")));
                }
                //print_r($months);
                $outputarray = array();
                $userqry = "SELECT COUNT(id) AS cnt, MONTH(created_at) AS cmonth, CONCAT(YEAR(created_at),'-',MONTH(created_at)) AS peroid FROM users WHERE created_at > DATE_ADD(NOW(), INTERVAL- 7 MONTH) GROUP BY cmonth ORDER BY MONTH(created_at) DESC";
                $userres = DB::select(DB::raw($userqry));
                $userres = (array)$userres;

                $billqry = "SELECT COUNT(id) AS cnt, MONTH(created_at) AS cmonth, CONCAT(YEAR(created_at),'-',MONTH(created_at)) AS peroid FROM billings WHERE created_at > DATE_ADD(NOW(), INTERVAL- 7 MONTH) GROUP BY cmonth ORDER BY MONTH(created_at) DESC";
                $billres = DB::select(DB::raw($billqry));
                $billres = (array)$billres;

                $amcqry = "SELECT COUNT(id) AS cnt, MONTH(created_at) AS cmonth, CONCAT(YEAR(created_at),'-',MONTH(created_at)) AS peroid FROM amc_requests WHERE created_at > DATE_ADD(NOW(), INTERVAL- 7 MONTH) GROUP BY cmonth ORDER BY MONTH(created_at) DESC";
                $amcres = DB::select(DB::raw($amcqry));
                $amcres = (array)$amcres;

                $visitorqry = "SELECT COUNT(id) AS cnt,now() as cdate, MONTH(created_at) AS cmonth, CONCAT(YEAR(created_at),'-',MONTH(created_at)) AS peroid FROM visitors WHERE created_at > DATE_ADD(NOW(), INTERVAL- 7 MONTH) GROUP BY cmonth ORDER BY MONTH(created_at) DESC";
                $visitres = DB::select(DB::raw($visitorqry));
                $visitres = (array)$visitres;

                for ($i=0; $i < sizeof($months) ; $i++) { 
                    $tmparray=array('period'=>$months[$i],'users'=>0,'billed'=>0,'amc'=>0,'visitors'=>0);
                    for ($u=0; $u < sizeof($userres) ; $u++) { 
                        if($months[$i]==$userres[$u]->peroid){
                            $tmparray['users']=$userres[$u]->cnt;
                        }
                    }
                    for ($u=0; $u < sizeof($billres) ; $u++) { 
                        if($months[$i]==$billres[$u]->peroid){
                            $tmparray['billed']=$billres[$u]->cnt;
                        }
                    }
                    for ($u=0; $u < sizeof($amcres) ; $u++) { 
                        if($months[$i]==$amcres[$u]->peroid){
                            $tmparray['amc']=$amcres[$u]->cnt;
                        }
                    }
                    for ($u=0; $u < sizeof($visitres) ; $u++) {
                        if($months[$i]==$visitres[$u]->peroid){
                            $tmparray['visitors']=$visitres[$u]->cnt;
                        }
                    }
                    $outputarray[]=$tmparray;
                }
                //echo json_encode($outputarray);
                //exit;
                $requestdata = DB::table('contacts')->leftJoin('users', 'users.id', '=', 'contacts.user_id')->orderBy('contacts.id', 'DESC')->get(array('contacts.*','users.name'));

                return view('admin.dashboard',compact('requestdata','outputarray'))->with('name',$name);

            }else{

                $workdata = DB::table('contacts')->where('user_id','=',$id)->orderBy('id', 'DESC')->get(); 

                $userdata = DB::table('users')->where('id','=',$id)->first();

                $blogdata = DB::table('blogs')->where('created_by','=',$id)->get();

                $quotationdata = DB::table('quotations')->leftJoin('billings', 'quotations.quotation_id', '=', 'billings.quotation_id')->where('quotations.to_email','=',$email)->orderBy('quotations.id', 'DESC')->get(array('quotations.*','billings.bill_no','billings.md5_bill_no','billings.completion_date as billdate','billings.work_status as billstatus'));
                $amcdata = DB::table('amc_requests')->select(DB::raw('GROUP_CONCAT(amc_request_services.price) as price,GROUP_CONCAT(services.service_name) as services,GROUP_CONCAT(amc_request_services.service_id) as serviceids,GROUP_CONCAT(amc_request_services.visits) as visits,GROUP_CONCAT(amc_request_services.balance_visit) as balancevisit,amc_requests.*,amcs.amc_type'))->leftJoin('amcs', 'amc_requests.amc_id', '=', 'amcs.id')->leftJoin('amc_request_services', 'amc_requests.id', '=', 'amc_request_services.request_id')->leftJoin('services', 'services.id', '=', 'amc_request_services.service_id')->where('amc_requests.user_id','=',$id)->groupBy('amc_requests.id')->orderBy('amc_requests.id', 'DESC')->get();
                $requested = DB::table('amc_requesteds')->leftJoin('services', 'amc_requesteds.service_id', '=', 'services.id')->leftJoin('amc_requests', 'amc_requests.id', '=', 'amc_requesteds.request_id')->leftJoin('amcs', 'amc_requests.amc_id', '=', 'amcs.id')->where('amc_requesteds.user_id','=',$id)->orderBy('amc_requesteds.id', 'DESC')->get(array('amc_requesteds.*','services.service_name','amcs.amc_type'));
                $completedworks = DB::table('amc_completeds')->leftJoin('services', 'amc_completeds.service_id', '=', 'services.id')->leftJoin('amc_requests', 'amc_requests.id', '=', 'amc_completeds.request_id')->leftJoin('amcs', 'amc_requests.amc_id', '=', 'amcs.id')->where('amc_requests.user_id','=',$id)->orderBy('amc_requests.id', 'DESC')->get(array('amc_completeds.*','services.service_name','amcs.amc_type'));
                $vehicledata = DB::table('vehiclewashes')->select(DB::raw('GROUP_CONCAT(vehilclewash_type_mapping.no_of_cars) as noofcars,GROUP_CONCAT(car_types.type_name) as cartypenames,vehiclewashes.*'))->leftJoin('vehilclewash_type_mapping', 'vehiclewashes.id', '=', 'vehilclewash_type_mapping.vehiclewash_id')->leftJoin('car_types', 'car_types.id', '=', 'vehilclewash_type_mapping.car_type_id')->where('vehiclewashes.user_id', '=', $id)->groupBy('vehiclewashes.id')->orderBy('vehiclewashes.id', 'DESC')->get();
                $rnodata = DB::table('vehiclewashes')->select(DB::raw('GROUP_CONCAT(vehilclewash_rno_mapping.rno) as rnos,vehiclewashes.*'))->leftJoin('vehilclewash_rno_mapping', 'vehiclewashes.id', '=', 'vehilclewash_rno_mapping.vehiclewash_id')->where('vehiclewashes.user_id', '=', $id)->groupBy('vehiclewashes.id')->orderBy('vehiclewashes.id', 'DESC')->get();
                //update initial flag

                if($userdata->init_flag==0){

                    $input = array('init_flag'=>1);

                    $contact = User::where('id','=',$id)->first();

                    $contact->fill($input)->save();

                }            

                return view('dashboard.index',compact('workdata','userdata','blogdata','quotationdata','amcdata','requested','completedworks','vehicledata','rnodata'))->with('name',$name);

            }            

        }

        else{

            $workdata = DB::table('contacts')->orderBy('id', 'DESC')->get(); 

            return view('dashboard.index',compact('workdata'))->with('name',$name);

        }

                   

        

    }

    public function changeworkstatus(Request $request){

        $data = $request->all();

        //print_r($data);

        $input = array('work_status'=>$data['status']);

        $contact = Contact::where('id','=',$data['id'])->first();

        $contact->fill($input)->save();

    }

    public function saveprofile(Request $request){

        $data = $request->all();

        if(Auth::check()){

            $id = Auth::user()->id;

            if($id==4){

                $user = User::where('id','=',$data['hidid'])->first();

                $email = $user->email;

                //$email = 'sridhars151@gmail.com';

                $phone = $data['contactno'];

                $to      = $email;

                $subject = 'Profile updated';

                //$message = 'Hi,<br>Your profile has been updated by Admin. Please login and check your details.';
                $message='<table width="100%"><tr><td><img style="width:100%" src="'.url().'/facilitiz/img/header.png"></td></tr><tr><td>Dear Sir/Madam,<br></td></tr>
            <tr><td>Your profile has been updated by Admin. Please login and check your details.<td></tr>
            <tr><td><br>Please <a href="'.url().'">click here</a> to login.</td></tr>
            <tr><td><br>--</td></tr>
            <tr><td>Thanks & regards,</td></tr>
            <tr><td>Facilitz Concierge Services Pvt. Ltd.</td></tr>
            <tr><td>E-Mail: sales@facilitz.com</td></tr>
            <tr><td>Website: www.facilitz.com</td></tr>
            <tr><td><br>-----------------------------</td></tr>
            <tr><td>Note: This is an auto generated mail. Please do not reply to this mail as it will not be responded or attended. Kindly contact in the mail ID given in signature line.</td></tr>
            <tr><td><img style="width:100%" src="'.url().'/facilitiz/img/footer.png"></td></tr>
            </table>';

                $headers  = 'MIME-Version: 1.0' . "\r\n";

                $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

                $headers .= 'From: services@facilitz.com' . "\r\n";

                mail($to, $subject, $message, $headers);

                if(preg_match("/^([0-9]){10}?$/", $phone)){

                    $msg = "Your profile has been updated by Admin";

                    $msg = rawurlencode($msg);
                    $url = "http://www.smsjust.com/sms/user/urlsms.php?username=facilitz&pass=sms@facilitz123&senderid=FACLTZ&dest_mobileno=91".$phone."&message=".$msg."&response=Y";

                    // Create a curl handle

                    $ch = curl_init($url);

                    // Execute

                    curl_exec($ch);

                    // Close handle

                    curl_close($ch);

                }

            }

            else

                $user = User::where('id','=',$id)->first();

            $user->fill($data)->save();

        }

        

    }

}

