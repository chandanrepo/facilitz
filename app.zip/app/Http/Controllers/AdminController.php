<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use App\Contact;
use App\User;
use Auth;
use App\Miscellaneous;
use App\Quotations;
use App\QuotationParticulars;
use App\QuotationWorkSteps;
use PDF;
use App\Billings;
use Mail;
use App\Installments;
use App\BillAdditional;
use App\Expenditures;
use App\Amcs;
use App\AmcCompleted;
use App\CarTypes;
use App\Locations;
use App\Services;
class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        return view('admin.index');        
    }
    public function loadpage(Request $request)
    {
        $data = $request->all();
        $page = $data['page'];
        if($page=='users'){
            $userdata = DB::table('users')->where('id','<>',4)->orderBy('users.id','DESC')->get();
            return view('admin.users',compact('userdata'));
        }
        if($page=='contactus'){
            $messagedata = DB::table('messages')->orderBy('messages.id','DESC')->get();
            return view('admin.contactus',compact('messagedata'));
        }
        if($page=='typeofcars'){
            $cardata = DB::table('car_types')->get();
            return view('admin.typeofcars',compact('cardata'));
        }
        if($page=='locations'){
            $locationdata = DB::table('locations')->get();
            return view('admin.locations',compact('locationdata'));
        }
        if($page=='vehicleservices'){
            $vehicledata = DB::table('vehiclewashes')->select(DB::raw('GROUP_CONCAT(vehilclewash_type_mapping.no_of_cars) as noofcars,GROUP_CONCAT(car_types.type_name) as cartypenames,vehiclewashes.*,users.name'))->leftJoin('vehilclewash_type_mapping', 'vehiclewashes.id', '=', 'vehilclewash_type_mapping.vehiclewash_id')->leftJoin('car_types', 'car_types.id', '=', 'vehilclewash_type_mapping.car_type_id')->leftJoin('users', 'users.id', '=', 'vehiclewashes.user_id')->groupBy('vehiclewashes.id')->orderBy('vehiclewashes.id', 'DESC')->get();
            $rnodata = DB::table('vehiclewashes')->select(DB::raw('GROUP_CONCAT(vehilclewash_rno_mapping.rno) as rnos,vehiclewashes.*'))->leftJoin('vehilclewash_rno_mapping', 'vehiclewashes.id', '=', 'vehilclewash_rno_mapping.vehiclewash_id')->groupBy('vehiclewashes.id')->orderBy('vehiclewashes.id', 'DESC')->get();
            return view('admin.vehicleservices',compact('vehicledata','rnodata'));
        }
        if($page=='amc'){
            $servicedata = DB::table('services')->get();
            $amcdata = DB::table('amcs')->select(DB::raw('GROUP_CONCAT(amc_services.price) as price,GROUP_CONCAT(amc_services.service_id) as services,GROUP_CONCAT(amc_services.visits) as visits,amcs.*'))->leftJoin('amc_services', 'amcs.id', '=', 'amc_services.amc_id')->groupBy('amcs.id')->orderBy('amcs.id', 'DESC')->get();
            return view('admin.amc',compact('servicedata','amcdata'));
        }
        if($page=='amcrequest'){
            $amcdata = DB::table('amc_requests')->select(DB::raw('GROUP_CONCAT(amc_request_services.price) as price,GROUP_CONCAT(services.service_name) as services,GROUP_CONCAT(amc_request_services.service_id) as serviceids,GROUP_CONCAT(amc_request_services.visits) as visits,GROUP_CONCAT(amc_request_services.balance_visit) as balancevisit,amc_requests.*,amcs.amc_type,amc_carts.name as company_name,amc_carts.email,amc_carts.phone as contactno'))->leftJoin('amc_carts', 'amc_requests.id', '=', 'amc_carts.request_id')->leftJoin('amcs', 'amc_requests.amc_id', '=', 'amcs.id')->leftJoin('amc_request_services', 'amc_requests.id', '=', 'amc_request_services.request_id')->leftJoin('services', 'services.id', '=', 'amc_request_services.service_id')->groupBy('amc_requests.id')->orderBy('amc_requests.id', 'DESC')->get();
            return view('admin.amcrequest',compact('amcdata'));
        }
        if($page=='amcservices'){
            $amcdata = DB::table('amc_requesteds')->leftJoin('services', 'amc_requesteds.service_id', '=', 'services.id')->leftJoin('amc_requests', 'amc_requests.id', '=', 'amc_requesteds.request_id')->leftJoin('amcs', 'amc_requests.amc_id', '=', 'amcs.id')->leftJoin('users', 'amc_requesteds.user_id', '=', 'users.id')->orderBy('amc_requesteds.id', 'DESC')->get(array('amc_requesteds.*','services.service_name','amcs.amc_type','users.company_name','users.email','users.contactno','amc_requests.amc_id'));
            return view('admin.amcservices',compact('amcdata'));
        }
        if($page=='quotation'){
            $misdata = DB::table('miscellaneouses')->first();
            $servicedata = DB::table('services')->get();
            $quotationdata = DB::table('quotations')->leftJoin('services', 'quotations.service_id', '=', 'services.id')->where('quotations.quotation_id','<>','')->orderBy('quotations.id', 'DESC')->get(array('quotations.*','services.service_name'));
            return view('admin.quotation',compact('misdata','servicedata','quotationdata'));
        }
        if($page=='billing'){
            $billdata = DB::table('billings')->select(DB::raw('GROUP_CONCAT(installments.amount) as installments,billings.*'))->leftJoin('installments', 'billings.id', '=', 'installments.bill_id')->groupBy('billings.id')->orderBy('billings.id', 'DESC')->get();

            $quotationdata = DB::table('quotations')->orderBy('id', 'DESC')->get();
            $expdata = DB::table('expenditures')->select(DB::raw('GROUP_CONCAT(description) as description,GROUP_CONCAT(amount) as amount,GROUP_CONCAT(exp_date) as exp_date,quotation_id'))->groupBy('quotation_id')->orderBy('quotation_id', 'DESC')->get();
            $months = array();
            for ($i = 6; $i >= 0; $i--) {
              array_push($months, date('Y-n', strtotime("-$i month")));
            }
            $outputarray = array();
            $visitorqry = "SELECT SUM(amount) AS cnt, MONTH(exp_date) AS cmonth, CONCAT(YEAR(exp_date),'-',MONTH(exp_date)) AS peroid FROM expenditures WHERE exp_date > DATE_ADD(NOW(), INTERVAL- 7 MONTH) GROUP BY cmonth ORDER BY MONTH(exp_date) DESC";
            $visitres = DB::select(DB::raw($visitorqry));
            $visitres = (array)$visitres;
            for ($i=0; $i < sizeof($months) ; $i++) { 
                $tmparray=array('period'=>$months[$i],'amount'=>0);
                for ($u=0; $u < sizeof($visitres) ; $u++) { 
                    if($months[$i]==$visitres[$u]->peroid){
                        $tmparray['amount']=$visitres[$u]->cnt;
                    }
                }
                $outputarray[]=$tmparray;
            }
            return view('admin.billing',compact('billdata','quotationdata','expdata','outputarray'));
        }
        if($page=='miscellaneous'){
            $misdata = DB::table('miscellaneouses')->first();
            return view('admin.miscellaneous',compact('misdata'));
        }
        if($page=='blog'){
            $blogdata = DB::table('blogs')->leftJoin('users', 'blogs.created_by', '=', 'users.id')->orderBy('id', 'DESC')->get(array('blogs.*','users.name'));
            return view('admin.blog',compact('blogdata'));
        }
        if($page=='affiliate'){
            $affiliatedata = DB::table('afliates')->leftJoin('services', 'services.id', '=', 'afliates.service_id')->orderBy('afliates.id', 'DESC')->get(array('afliates.*','services.service_name'));
            return view('admin.affiliate',compact('affiliatedata'));
        }
        if($page=='skilldevelopment'){
            $skilldata = DB::table('skill_developments')->orderBy('id', 'DESC')->get();
            return view('admin.skilldevelopment',compact('skilldata'));
        }
        if($page=='services'){
            $servicedata = DB::table('services')->orderBy('id', 'DESC')->get();
            return view('admin.services',compact('servicedata'));
        }
        if($page=='customerreport'){
            return view('admin.customerreport');
        }
        if($page=='customerbill'){
            return view('admin.customerbill');
        }
    }
    public function savemiscellaneous(Request $request){
        $data = $request->all();
        $mis = Miscellaneous::where('id','=',1)->first();
        $mis->fill($data)->save();
    }
    public function savequotation(Request $request){
        $data = $request->all();
        $date = date('Y-m-d H:i:s');
        $to = $data['to_email'];
        $phone  = $data['to_mobile'];
        $data['quotation_date'] = str_replace('/', '-', $data['quotation_date']);
        $data['quotation_date']=date('Y-m-d',strtotime($data['quotation_date']));
        $id=$data['id'];
        if($id!=''){
            $mis = Quotations::where('id','=',$id)->first();
            $mis->fill($data)->save();
        }
        else{
            $data['completion_date']='';
            if($data['completion_date']!='' and $data['completion_date']!='0000-00-00'){
                $data['completion_date'] = str_replace('/', '-', $data['completion_date']);
                $cdate = date('Y-m-d',strtotime($data['completion_date']));
                $data['completion_date']=$cdate;
            }
            //new quotation
            $res = Quotations::create($data);
            $id = $res->{'id'};
            $mis = Quotations::where('id','=',$id)->first();
            //generate quation id
            $qid = "FCS00009".sprintf("%04s",$id);
            $input = array('quotation_id'=>$qid,'md5_quotation_id'=>md5($qid));

            //save particulars
            $qarray = array();
            $particular_col1 = explode(',',$data['particular_col1']);
            $particular_col2 = explode(',',$data['particular_col2']);
            $particular_col3 = explode(',',$data['particular_col3']);
            $particular_col4 = explode(',',$data['particular_col4']);
            $particular_col5 = explode(',',$data['particular_col5']);
            $amount=0;
            for ($i=0; $i < sizeof($particular_col1) ; $i++) { 
                $qarray[] = array('quotation_id'=>$id,'col1'=>$particular_col1[$i],'col2'=>$particular_col2[$i],'col3'=>$particular_col3[$i],'col4'=>$particular_col4[$i],'col5'=>$particular_col5[$i],'created_at'=>$date);
                $amount = $amount+$particular_col5[$i];
            }
            $input['total_amount']=$amount;
            $mis->fill($input)->save();
            if(sizeof($qarray)>0)
                DB::table('quotation_particulars')->insert($qarray);

            //save steps
            $stepsarray = array();
            $steps = explode(',',$data['steps']);
            for ($i=0; $i < sizeof($steps) ; $i++) { 
                $stepsarray[] = array('quotation_id'=>$id,'steps'=>$steps[$i],'created_at'=>$date);
            }
            if(sizeof($qarray)>0)
                DB::table('quotation_work_steps')->insert($stepsarray);

            //generate pdf
            $data = array();
            $quotedata = DB::table('quotations')->leftJoin('services', 'quotations.service_id', '=', 'services.id')->where('quotations.id','=',$id)->first(array('quotations.*','services.service_name'));
            $misdata = DB::table('miscellaneouses')->first();
            $particulars = DB::table('quotation_particulars')->where('quotation_id','=',$id)->get();
            $steps = DB::table('quotation_work_steps')->where('quotation_id','=',$id)->get();
            $data['quotationdata']=$quotedata;
            $data['misdata']=$misdata;
            $data['particulars']=$particulars;
            $data['steps']=$steps;
            PDF::loadView('admin.pdf', $data)->save('quotations/'.$qid.'.pdf');

            $qurl = url()."/pdfviewer/web/viewer.html?file=".$qid.".pdf&type=1";
            $subject = 'Quotation from Facilitz';
            //$message = 'Dear Sir/Madam,<br>Your quotation is prepared with quotation no:'.$qid.'<br><a href="'.$qurl.'">Click here to view quotation</a>';
            $message = '<table width="100%"><tr><td><img style="width:100%" src="'.url().'/facilitiz/img/header.png"></td></tr><tr><td>Dear Sir/Madam,<br></td></tr>
            <tr><td>Greetings from Facilitz Concierge Services Pvt. Ltd. With reference to your enquiry, we have prepared your quotation with quotation no: '.$qid.'<td></tr>
            <tr><td><br>Please<a href="'.$qurl.'"> click here </a>to view your quotation.</td></tr>
            <tr><td><br>Please feel free to discuss with us if you have any queries. We hope to serve you better with positive enduring commitment in years to come.</td></tr>
            <tr><td><br>--</td></tr>
            <tr><td>Thanks & regards,</td></tr>
            <tr><td>Facilitz Concierge Services Pvt. Ltd.</td></tr>
            <tr><td>E-Mail: sales@facilitz.com</td></tr>
            <tr><td>Website: www.facilitz.com</td></tr>
            <tr><td><br>-----------------------------</td></tr>
            <tr><td>Note: This is an auto generated mail. Please do not reply to this mail as it will not be responded or attended. Kindly contact in the mail ID given in signature line.</td></tr>
            <tr><td><img style="width:100%" src="'.url().'/facilitiz/img/footer.png"></td></tr>
            </table>';         
            $headers  = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $headers .= 'From: services@facilitz.com' . "\r\n";
            mail($to, $subject, $message, $headers);

            if(preg_match("/^([0-9]){10}?$/", $phone)){
                $msg = "Dear Sir/Madam,Your quotation is prepared with quotation no: ".$qid." and is mailed to your e-mail id. Kindly check your mail. Regards, www.facilitz.com";
                $msg = rawurlencode($msg);
                $url = "http://www.smsjust.com/sms/user/urlsms.php?username=facilitz&pass=sms@facilitz123&senderid=FACLTZ&dest_mobileno=91".$phone."&message=".$msg."&response=Y";
                // Create a curl handle
                $ch = curl_init($url);
                // Execute
                curl_exec($ch);
                // Close handle
                curl_close($ch);
            }
        }        
    }
    public function testpdf(Request $request){
        Mail::raw('Laravel with Mailgun is easy!', function($message)
{
    $message->to('sridhars151@gmail.com');
});
        echo "string";

//         $data = array('id'=>1);
//         Mail::send('welcome', $data, function ($message) {
//     $message->from('sales@facilitz.com', 'Laravel');

//     $message->to('sridhars151@gmail.com');
// });
        exit;
        $data = array();
        $id=7;
        $qid='FCS000090007';
        $quotedata = DB::table('quotations')->leftJoin('services', 'quotations.service_id', '=', 'services.id')->where('quotations.id','=',$id)->first(array('quotations.*','services.service_name'));
        $misdata = DB::table('miscellaneouses')->first();
        $particulars = DB::table('quotation_particulars')->where('quotation_id','=',$id)->get();
        $steps = DB::table('quotation_work_steps')->where('quotation_id','=',$id)->get();
        $data['quotationdata']=$quotedata;
        $data['misdata']=$misdata;
        $data['particulars']=$particulars;
        $data['steps']=$steps;
        PDF::loadView('admin.pdf', $data)->save('quotations/'.$qid.'.pdf');
        return view('admin.test')->with('data',$data);
    }
    public function savebilling(Request $request){
        $data = $request->all();
        $date = date('Y-m-d H:i:s');
        $quotation_id = $data['quotation_id'];
        $data['completion_date']='';
        if($data['completion_date']!='' and $data['completion_date']!='0000-00-00'){
            $cdate = date('Y-m-d',strtotime($data['completion_date']));
            $data['completion_date']=$cdate;
        }
        $res = Billings::create($data);
        $id = $res->{'id'};
        $mis = Billings::where('id','=',$id)->first();
        //generate bill number and update
        $qid = "IN009".sprintf("%04s",$id);
        $input = array('bill_no'=>$qid,'md5_bill_no'=>md5($qid));
        $mis->fill($input)->save();
        $mis['bill_no']=$qid;
        //save into installment table
        $insarray = array('bill_id'=>$id,'amount'=>$data['amount_paid']);
        Installments::create($insarray);

        //save additional info
        $qarray = array();
        $desc1 = explode(',',$data['desc1']);
        $desc2 = explode(',',$data['desc2']);
        for ($i=0; $i < sizeof($desc1) ; $i++) { 
            if($desc1[$i]!='' and $desc2[$i]!='')
                $qarray[] = array('bill_id'=>$id,'description'=>$desc1[$i],'amount'=>$desc2[$i],'created_at'=>$date);
        }
        if(sizeof($qarray)>0)
            DB::table('bill_additionals')->insert($qarray);

        //generate pdf        
        $quotedata = DB::table('quotations')->where('quotation_id','=',$data['quotation_id'])->first();
        $misdata = DB::table('miscellaneouses')->first();
        $ins = Installments::where('bill_id','=',$id)->get();
        $additional = BillAdditional::where('bill_id','=',$id)->get();
        $data = array();
        $data['quotationdata']=$quotedata;
        $data['misdata']=$misdata;
        $data['billdata']=$mis;
        $data['adddata']=$additional;
        $data['insdata']=$ins;
        PDF::loadView('admin.billpdf', $data)->save('bills/'.$qid.'.pdf');

        $qurl = url()."/pdfviewer/web/viewer.html?file=".$qid.".pdf&type=2";
        $to = $quotedata->to_email;
        $phone = $quotedata->to_mobile;

        $subject = 'Bill from Facilitz';
        //$message = 'Dear Sir/Madam,<br>Your bill no:'.$qid.' w.r.t. quotation ref. no: '.$quotation_id.'<br><a href="'.$qurl.'">Click here to view you bill</a>';
        $message = '<table width="100%"><tr><td><img style="width:100%" src="'.url().'/facilitiz/img/header.png"></td></tr><tr><td>Dear Sir/Madam,<br></td></tr>
            <tr><td>Greetings from Facilitz Concierge Services Pvt. Ltd. With reference to your quotation no: '.$quotation_id.', we have prepared your bill with bill no: '.$qid.'. <td></tr>
            <tr><td><br>Please<a href="'.$qurl.'"> click here </a>to view your bill.</td></tr>
            <tr><td><br>Please feel free to discuss with us if you have any queries. We hope to serve you better with positive enduring commitment in years to come.</td></tr>
            <tr><td><br>--</td></tr>
            <tr><td>Thanks & regards,</td></tr>
            <tr><td>Facilitz Concierge Services Pvt. Ltd.</td></tr>
            <tr><td>E-Mail: sales@facilitz.com</td></tr>
            <tr><td>Website: www.facilitz.com</td></tr>
            <tr><td><br>-----------------------------</td></tr>
            <tr><td>Note: This is an auto generated mail. Please do not reply to this mail as it will not be responded or attended. Kindly contact in the mail ID given in signature line.</td></tr>
            <tr><td><img style="width:100%" src="'.url().'/facilitiz/img/footer.png"></td></tr>
            </table>';           
        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers .= 'From: services@facilitz.com' . "\r\n";
        mail($to, $subject, $message, $headers);

        if(preg_match("/^([0-9]){10}?$/", $phone)){
            $msg = "Dear Sir/Madam, Your bill no.: ".$qid." w.r.t. quotation ref. no.:".$quotation_id." has been mailed to your e-mail id. Kindly check your mail. Regards, www.facilitz.com";
            $msg = rawurlencode($msg);
            $url = "http://www.smsjust.com/sms/user/urlsms.php?username=facilitz&pass=sms@facilitz123&senderid=FACLTZ&dest_mobileno=91".$phone."&message=".$msg."&response=Y";
            // Create a curl handle
            $ch = curl_init($url);
            // Execute
            curl_exec($ch);
            // Close handle
            curl_close($ch);
        }
    }
    public function managebilling(Request $request){
        $data = $request->all();
        $id = $data['hidid'];
        $updatearray = array();
        $updatearray['completion_date']='';
        if($data['completion_date']!='' and $data['completion_date']!='0000-00-00'){
            $cdate = date('Y-m-d',strtotime($data['completion_date']));
            $updatearray['completion_date']=$cdate;
        }
        //update to bills table
        $updatearray['pending_amount']=$data['pending_amount'];
        $updatearray['work_status']=$data['work_status'];
        
        $bill = Billings::where('id','=',$id)->first();
        $bill->fill($updatearray)->save();
        $billname = $bill['bill_no'];
        
        if($data['amount_paid']!=''){
            //Insert Installment table
            $insarray = array('amount'=>$data['amount_paid'],'bill_id'=>$id);
            Installments::create($insarray);
        }

        //remove old file
        unlink($_SERVER['DOCUMENT_ROOT'].'/public/bills/'.$billname.'.pdf');
        //generate pdf
        $quotation_id = $data['quotation_id'];        
        $quotedata = DB::table('quotations')->where('quotation_id','=',$data['quotation_id'])->first();
        $misdata = DB::table('miscellaneouses')->first();
        $ins = Installments::where('bill_id','=',$id)->get();
        $additional = BillAdditional::where('bill_id','=',$id)->get();
        $mis = Billings::where('id','=',$id)->first();
        $data = array();
        $data['quotationdata']=$quotedata;
        $data['misdata']=$misdata;
        $data['billdata']=$mis;
        $data['adddata']=$additional;
        $data['insdata']=$ins;
        PDF::loadView('admin.billpdf', $data)->save('bills/'.$billname.'.pdf');

        
        $qurl = url()."/pdfviewer/web/viewer.html?file=".$billname.".pdf&type=2";
        $to = $quotedata->to_email;
        $phone = $quotedata->to_mobile;

        $subject = 'Updated Bill from Facilitz';
        //$message = 'Dear Sir/Madam,<br>Your bill no:'.$billname.' w.r.t. quotation ref. no: '.$quotation_id.'<br><a href="'.$qurl.'">Click here to view you bill</a>'; 
        $message = '<table width="100%"><tr><td><img style="width:100%" src="'.url().'/facilitiz/img/header.png"></td></tr><tr><td>Dear Sir/Madam,<br></td></tr>
            <tr><td>Greetings from Facilitz Concierge Services Pvt. Ltd. With reference to your quotation no: '.$quotation_id.', we have prepared your bill with bill no: '.$billname.'. <td></tr>
            <tr><td><br>Please<a href="'.$qurl.'"> click here </a>to view your bill.</td></tr>
            <tr><td><br>Please feel free to discuss with us if you have any queries. We hope to serve you better with positive enduring commitment in years to come.</td></tr>
            <tr><td><br>--</td></tr>
            <tr><td>Thanks & regards,</td></tr>
            <tr><td>Facilitz Concierge Services Pvt. Ltd.</td></tr>
            <tr><td>E-Mail: sales@facilitz.com</td></tr>
            <tr><td>Website: www.facilitz.com</td></tr>
            <tr><td><br>-----------------------------</td></tr>
            <tr><td>Note: This is an auto generated mail. Please do not reply to this mail as it will not be responded or attended. Kindly contact in the mail ID given in signature line.</td></tr>
            <tr><td><img style="width:100%" src="'.url().'/facilitiz/img/footer.png"></td></tr>
            </table>';             
        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers .= 'From: services@facilitz.com' . "\r\n";
        mail($to, $subject, $message, $headers);

        if(preg_match("/^([0-9]){10}?$/", $phone)){
            $msg = "Dear Sir/Madam, Your bill no.: ".$billname." w.r.t. quotation ref. no.:".$quotation_id." has been updated and mailed to your e-mail id. Kindly check your mail. Regards, www.facilitz.com";
            $msg = rawurlencode($msg);
            $url = "http://www.smsjust.com/sms/user/urlsms.php?username=facilitz&pass=sms@facilitz123&senderid=FACLTZ&dest_mobileno=91".$phone."&message=".$msg."&response=Y";
            // Create a curl handle
            $ch = curl_init($url);
            // Execute
            curl_exec($ch);
            // Close handle
            curl_close($ch);
        }
    }
    public function saveexpenditure(Request $request){
        $data = $request->all();
        $date = date('Y-m-d H:i:s');
        $qarray = array();
        $exp1 = explode(',',$data['exp1']);
        $exp2 = explode(',',$data['exp2']);
        $exp3 = explode(',',$data['exp3']);
        for ($i=0; $i < sizeof($exp1) ; $i++) { 
            if($exp1[$i]!='' and $exp2[$i]!='' and $exp3[$i]!='')
                $qarray[] = array('quotation_id'=>$data['quotation_id'],'description'=>$exp2[$i],'amount'=>$exp3[$i],'exp_date'=>date('Y-m-d',strtotime($exp1[$i])),'created_at'=>$date);
        }
        if(sizeof($qarray)>0)
            DB::table('expenditures')->insert($qarray);
    }
    public function managequotation(Request $request){
        $data = $request->all();
        $id = $data['hidid'];
        $updatearray = array();
        $updatearray['completion_date']='';
        if($data['completion_date']!='' and $data['completion_date']!='0000-00-00'){
            $cdate = date('Y-m-d',strtotime($data['completion_date']));
            $updatearray['completion_date']=$cdate;
        }
        $updatearray['work_status']=$data['work_status'];
        $updatearray['progress']=$data['progress'];
        
        $quotations = Quotations::where('id','=',$id)->first();
        $quotations->fill($updatearray)->save();
    }
    public function saveamc(Request $request){
        $data = $request->all();
        $date = date('Y-m-d H:i:s');

        $insarray = array('amc_type'=>$data['amc_type']);
        $id = $data['hidid'];
        if($id!=0){
            $amc = Amcs::where('id','=',$id)->first();
            $amc->fill($insarray)->save();
            DB::table('amc_services')->where('amc_id', '=',$id)->delete();
            DB::table('amc_range')->where('amc_id', '=',$id)->delete();
        }
        else{
            $res = Amcs::create($insarray);
            $id = $res->{'id'};
        }

        $qarray = array();
        $servicearray = explode(',',$data['servicearray']);
        $pricearray = explode(',',$data['pricearray']);
        $visitarray = explode(',',$data['visitarray']);
        $noofservice = 0;
        for ($i=0; $i < sizeof($servicearray) ; $i++) { 
            if($servicearray[$i]!='' and $pricearray[$i]!='' and $visitarray[$i]!='')
                $qarray[] = array('amc_id'=>$id,'service_id'=>$servicearray[$i],'price'=>$pricearray[$i],'visits'=>$visitarray[$i],'created_at'=>$date);
            $noofservice = $noofservice+$visitarray[$i];
        }
        if(sizeof($qarray)>0)
            DB::table('amc_services')->insert($qarray);

        $amc = Amcs::where('id','=',$id)->first();
        $amc->fill(array('no_of_services'=>$noofservice))->save();

        // //price range
        // $qarray1 = array();
        // $range_from = explode(',',$data['range_from']);
        // $range_to = explode(',',$data['range_to']);
        // $visit = explode(',',$data['visit']);
        // for ($i=0; $i < sizeof($range_from) ; $i++) { 
        //     if($range_from[$i]!='' and $range_to[$i]!='' and $visit[$i]!='')
        //         $qarray1[] = array('amc_id'=>$id,'range_from'=>$range_from[$i],'range_to'=>$range_to[$i],'no_of_visit'=>$visit[$i],'created_at'=>$date);
        // }
        // if(sizeof($qarray1)>0)
        //     DB::table('amc_range')->insert($qarray1);
    }
    public function requestcomplete(Request $request)
    {
        $request = $request->all();
        $insarray = array('service_id'=>$request['hidserviceid'],'request_id'=>$request['hidrequestid'],'completed_date'=>date('Y-m-d',strtotime($request['completed_date'])),'comments'=>$request['comments'],'amc_id'=>$request['hidamcid']);
        AmcCompleted::create($insarray);

        DB::table('amc_requesteds')->where('id', '=',$request['hidid'])->delete();

        DB::table('amc_request_services')->where('request_id','=',$request['hidrequestid'])->where('service_id','=',$request['hidserviceid'])->where('amc_id','=',$request['hidamcid'])->decrement('balance_visit');
        DB::table('amc_requests')->where('id','=',$request['hidrequestid'])->decrement('balance_visit');
    }
    public function createuser(Request $request)
    {
        $request = $request->all();
        $password = rand();
        $request['password']=bcrypt($password);
        $id = Auth::user()->id;
        $request['email'] = strtolower($request['email']);
        $check = User::where('email','=',$request['email'])->first();
        if($id==4){
            if(!$check){
                $res = User::create($request);
                $to      = $request['email'];
                $subject = 'User details for Facilitz';
                //$message = 'Hi,<br>Your user account created successfully. Please login using following details.<br>Username: '.$request['email'].'<br>Password: '.$password;
                $message='<table width="100%"><tr><td><img style="width:100%" src="'.url().'/facilitiz/img/header.png"></td></tr><tr><td>Dear Sir/Madam,<br></td></tr>
            <tr><td>Greetings from Facilitz Concierge Services Pvt. Ltd. Your user account created successfully. Please login using following details.<br>Username: '.$request['email'].'<br>Password: '.$password.'<td></tr><tr><td><br>Please<a href="'.url().'/login"> click here </a>to login.</td></tr>
            <tr><td><br>--</td></tr>
            <tr><td>Thanks & regards,</td></tr>
            <tr><td>Facilitz Concierge Services Pvt. Ltd.</td></tr>
            <tr><td>E-Mail: sales@facilitz.com</td></tr>
            <tr><td>Website: www.facilitz.com</td></tr>
            <tr><td><br>-----------------------------</td></tr>
            <tr><td>Note: This is an auto generated mail. Please do not reply to this mail as it will not be responded or attended. Kindly contact in the mail ID given in signature line.</td></tr>
            <tr><td><img style="width:100%" src="'.url().'/facilitiz/img/footer.png"></td></tr>
            </table>';
                $headers  = 'MIME-Version: 1.0' . "\r\n";
                $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                $headers .= 'From: services@facilitz.com' . "\r\n";
                mail($to, $subject, $message, $headers);
                $phone = $request['contactno'];
                if(preg_match("/^([0-9]){10}?$/", $phone)){
                    $msg = "Your account has been created successfully. Please check your login details in your email account";
                    $msg = rawurlencode($msg);
                    $url = "http://www.smsjust.com/sms/user/urlsms.php?username=facilitz&pass=sms@facilitz123&senderid=FACLTZ&dest_mobileno=91".$phone."&message=".$msg."&response=Y";
                    // Create a curl handle
                    $ch = curl_init($url);
                    // Execute
                    curl_exec($ch);
                    // Close handle
                    curl_close($ch);
                }
            }
        }
    }
    public function savecar(Request $request){
        $data = $request->all();
        $input['type_name']=$data['type_name'];
        $input['price']=$data['price'];
        if($data['hidid']!=''){
            $ctype = CarTypes::where('id','=',$data['hidid'])->first();
            $ctype->fill($input)->save();
        }
        else{
            CarTypes::create($input);
        }        
    }
    public function deletecar(Request $request){
        $data = $request->all();
        $id=$data['id'];
        DB::table('car_types')->where('id', '=',$id)->delete();
    }
    public function savelocation(Request $request){
        $data = $request->all();
        $input['name']=$data['name'];
        if($data['hidid']!=''){
            $ctype = Locations::where('id','=',$data['hidid'])->first();
            $ctype->fill($input)->save();
        }
        else{
            Locations::create($input);
        }        
    }
    public function deletelocation(Request $request){
        $data = $request->all();
        $id=$data['id'];
        DB::table('locations')->where('id', '=',$id)->delete();
    }
    public function deleteuser(Request $request){
        if(Auth::check()){
            $id = Auth::user()->id;
            if($id==4){
                $data = $request->all();
                $id=$data['id'];
                DB::table('users')->where('id', '=',$id)->delete();
            }
        }
    }
    public function saveservice(Request $request){
        $data = $request->all();
        $input['service_name']=$data['service_name'];
        if($data['hidid']!=''){
            $ctype = Services::where('id','=',$data['hidid'])->first();
            $ctype->fill($input)->save();
        }
        else{
            Services::create($input);
        }        
    }
    public function deleteservice(Request $request){
        $data = $request->all();
        $id=$data['id'];
        DB::table('services')->where('id', '=',$id)->delete();
    }
    public function downloadcustomerreport(Request $request){
        $request = $request->all();
        $from_date = $request['from_date'];
        $to_date = $request['to_date'];
        $from_date =  date("Y-m-d H:i:s",strtotime($request['from_date']));
        $to_date =  date("Y-m-d H:i:s",strtotime($request['to_date']));
        $result = DB::table('contacts')->leftJoin('users', 'contacts.user_id', '=', 'users.id')->whereBetween('contacts.created_at', array($from_date, $to_date))->get(array('contacts.*','users.name'));
        $data=array('from_date'=>$request['from_date'],'to_date'=>$request['to_date']);
        $data['content']=$result;
        //return view('admin.customerpdf')->with('data',$data);
        $filename = date('d-m-Y',strtotime($request['from_date']))." to ". date('d-m-Y',strtotime($request['to_date'])).".pdf";
        $pdf = PDF::loadView('admin.customerpdf', $data);
        return $pdf->download($filename);
        //print_r($result);
        exit;
        // $pdf = PDF::loadView('welcome', $data);
        // return $pdf->download('invoice.pdf');
    }
    public function downloadcustomerbill(Request $request){
        $request = $request->all();
        $from_date = $request['from_date'];
        $to_date = $request['to_date'];
        $from_date =  date("Y-m-d H:i:s",strtotime($request['from_date']));
        $to_date =  date("Y-m-d H:i:s",strtotime($request['to_date']));
        $result = DB::table('billings')->leftJoin('quotations', 'quotations.quotation_id', '=', 'billings.quotation_id')->whereBetween('billings.created_at', array($from_date, $to_date))->get(array('billings.*','quotations.to_mobile','quotations.to_email'));
        $data=array('from_date'=>$request['from_date'],'to_date'=>$request['to_date']);
        $data['content']=$result;
        // return view('admin.customerbillpdf')->with('data',$data);
        // exit;
        $filename = date('d-m-Y',strtotime($request['from_date']))." to ". date('d-m-Y',strtotime($request['to_date'])).".pdf";
        $pdf = PDF::loadView('admin.customerbillpdf', $data);
        return $pdf->download($filename);
        //print_r($result);
        exit;
        // $pdf = PDF::loadView('welcome', $data);
        // return $pdf->download('invoice.pdf');
    }
}