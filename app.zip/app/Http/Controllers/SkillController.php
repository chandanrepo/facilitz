<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use Auth;
use Illuminate\Support\Facades\Input;
use Validator;
use Redirect;
use App\SkillDevelopments;
class SkillController extends Controller
{
    public function __construct()
    {
        //$this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        $id=0;
        $name='';
        if(Auth::check()){
            $id = Auth::user()->id;
            $name = Auth::user()->name;
        }
        return view('skilldevelopment.index')->with('id',$id)->with('name',$name);    
    }
    public function saveskillrequest(Request $request){
        $data = $request->all();
        if($data){
            $check = SkillDevelopments::where('email_id','=',$data['email_id'])->first();
            if(isset($check->{'id'})){
                return redirect('skilldevelopment')->withInput($data)->withErrors(array('Email id is already taken'));
                exit;
            }
            if (Input::hasFile('bpl'))
            {
                if (Input::file('bpl')->isValid())
                {
                    $extension = Input::file('bpl')->getClientOriginalExtension(); // getting image extension
                    $fileName = str_random(32) . '.' . $extension; // renameing image
                    $destinationPath = public_path('/img/skills');
                    Input::file('bpl')->move($destinationPath, $fileName);
                    $data['bpl_file_name'] = $fileName;
                }
            }
            if (Input::hasFile('adhar'))
            {
                if (Input::file('adhar')->isValid())
                {
                    $extension = Input::file('adhar')->getClientOriginalExtension(); // getting image extension
                    $fileName = str_random(32) . '.' . $extension; // renameing image
                    $destinationPath = public_path('/img/skills');
                    Input::file('adhar')->move($destinationPath, $fileName);
                    $data['adhar_file_name'] = $fileName;
                }
            }
            $res = SkillDevelopments::create($data);
            $id = $res->{'id'};
            $skill = SkillDevelopments::where('id','=',$id)->first();
            $id = "BPL".sprintf("%07s",$id);
            $input = array('ref_id'=>$id);
            $skill->fill($input)->save();

            $phone = $data['mobile_no'];
            $to = $data['email_id'];

            $subject = 'Skill Development request ';
            $message = '<table width="100%"><tr><td><img style="width:100%" src="'.url().'/facilitiz/img/header.png"></td></tr><tr><td>Dear Sir/Madam,<br></td></tr>
            <tr><td>Thank you for contacting us.Your Skill Development Request ID is '.$id.'. <td></tr>
            <tr><td><br>We will contact you shortly.</td></tr>
            <tr><td><br>--</td></tr>
            <tr><td>Thanks & regards,</td></tr>
            <tr><td>Facilitz Concierge Services Pvt. Ltd.</td></tr>
            <tr><td>E-Mail: sales@facilitz.com</td></tr>
            <tr><td>Website: www.facilitz.com</td></tr>
            <tr><td><br>-----------------------------</td></tr>
            <tr><td>Note: This is an auto generated mail. Please do not reply to this mail as it will not be responded or attended. Kindly contact in the mail ID given in signature line.</td></tr>
            <tr><td><img style="width:100%" src="'.url().'/facilitiz/img/footer.png"></td></tr>
            </table>';           
            $headers  = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $headers .= 'From: services@facilitz.com' . "\r\n";
            mail($to, $subject, $message, $headers);

            if(preg_match("/^([0-9]){10}?$/", $phone)){
                $msg = "Dear Sir/Madam, Thank you contacting us. Your Request Id is ".$id.". Skill development team will contact you shortly. Regards, www.facilitz.com";
                $msg = rawurlencode($msg);
                $url = "http://www.smsjust.com/sms/user/urlsms.php?username=facilitz&pass=sms@facilitz123&senderid=FACLTZ&dest_mobileno=91".$phone."&message=".$msg."&response=Y";
                // Create a curl handle
                $ch = curl_init($url);
                // Execute
                curl_exec($ch);
                // Close handle
                curl_close($ch);
            }
            return redirect('skilldevelopment')->with('status', 'Your request accepted successfully. We sent email regarding this. Our team will contact you soon.');
        }else{
            return Redirect::to('/skilldevelopment');
        }     
    }
}